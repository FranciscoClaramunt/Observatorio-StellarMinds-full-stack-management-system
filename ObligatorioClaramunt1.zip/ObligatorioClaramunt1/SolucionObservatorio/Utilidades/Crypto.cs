﻿using Konscious.Security.Cryptography;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Utilidades
{
    public class Crypto
    {
        public static string Hash(string password)
        {
            // Salt aleatorio
            byte[] salt = RandomNumberGenerator.GetBytes(16);

            var argon2 = new Argon2id(Encoding.UTF8.GetBytes(password))
            {
                Salt = salt,
                DegreeOfParallelism = 2, // hilos
                MemorySize = 65536,      // 64 MB
                Iterations = 4           // tiempo
            };

            byte[] hash = argon2.GetBytes(32);

            // Guardar: salt + hash (base64)
            return Convert.ToBase64String(salt) + "." + Convert.ToBase64String(hash);

        }
        public static bool Verify(string password, string storedHash)
        {
            var parts = storedHash.Split('.');
            byte[] salt = Convert.FromBase64String(parts[0]);
            byte[] hash = Convert.FromBase64String(parts[1]);

            var argon2 = new Argon2id(Encoding.UTF8.GetBytes(password))
            {
                Salt = salt,
                DegreeOfParallelism = 2,
                MemorySize = 65536,
                Iterations = 4
            };

            byte[] newHash = argon2.GetBytes(32);

            return CryptographicOperations.FixedTimeEquals(hash, newHash);
        }
    }
}
