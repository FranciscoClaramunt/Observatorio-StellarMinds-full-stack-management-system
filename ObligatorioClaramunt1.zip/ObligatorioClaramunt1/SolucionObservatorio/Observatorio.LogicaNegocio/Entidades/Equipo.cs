﻿using Observatorio.LogicaNegocio.Entidades.ValueObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades
{
    public class Equipo
    {
        public int Id { get; set; }
        public MarcaModelo MarcaModelo { get; set; }
        public int CantDisponible { get; set; }
    }
}
