﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades
{
    public class PrestamoEquipo
    {
        public int Id { get; set; }
        public EquipoTelescopio Telescopio { get; set; }
        public EquipoMontura Montura { get; set; }
        public EquipoCamara? Camara { get; set; }
        public EquipoOcular? Ocular { get; set; }
    }
}
