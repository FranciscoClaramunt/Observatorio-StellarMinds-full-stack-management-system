﻿using Observatorio.LogicaNegocio.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades
{
    public class EquipoMontura : Equipo
    {
        public TipoMontura Tipo { get; set; }
        public decimal Carga { get; set; }
        public bool Computarizado { get; set; }
    }
}
