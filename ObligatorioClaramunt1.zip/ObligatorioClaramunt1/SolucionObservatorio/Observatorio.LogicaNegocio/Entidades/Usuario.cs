﻿using Observatorio.LogicaNegocio.Entidades.ValueObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades
{
    public class Usuario
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string Pass { get; set; }
        public NombreApellido NombreCompleto { get; set; }
        public Direccion Direccion { get; set; }
        public string Telefono { get; set; }
        public string Email { get; set; }
        public int RolId { get; set; }
        public Rol Rol { get; set; }
        public List<Prestamo> Prestamos { get; set; }
        public List<Auditoria> Auditorias { get; set; }

    }
}
