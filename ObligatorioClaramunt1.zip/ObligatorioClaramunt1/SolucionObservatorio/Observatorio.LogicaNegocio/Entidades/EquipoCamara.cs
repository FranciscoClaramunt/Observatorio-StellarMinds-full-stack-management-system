﻿using Observatorio.LogicaNegocio.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades
{
    public class EquipoCamara : Equipo
    {
        public TipoSensor TipoCensor { get; set; }
        public string Resolucion { get; set; }
        public decimal TamanoPixel { get; set; }
    }
}
