﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades
{
    public class EquipoTelescopio : Equipo
    {
        public int Apertura { get; set; }
        public decimal RelacionFocal { get; set; }
        public int DistanciaFocal { get; set; }
        public decimal Peso { get; set; }
    }
}
