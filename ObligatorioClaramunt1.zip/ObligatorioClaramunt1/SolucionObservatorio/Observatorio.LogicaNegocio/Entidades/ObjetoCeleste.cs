﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades
{
    public class ObjetoCeleste
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Tipo { get; set; }
        public decimal MagnitudAparente { get; set; }
        public List<Observacion> Observaciones { get; set; }
    }
}
