﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades
{
    public class Auditoria
    {
        public int Id { get; set; }
        public Prestamo Prestamo { get; set; }
        public Usuario UsuarioCoordinador { get; set; }
        public DateTime Fecha { get; set; }
        public string Accion { get; set; }
    }
}
