﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades.ValueObjects
{
    [ComplexType]
    public record MarcaModelo
    {
        public string Marca { get; init; }
        public string Modelo { get; init; }

        public MarcaModelo(string marca, string modelo)
        {
            Marca = marca;
            Modelo = modelo;
        }
    }
}
