﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades.ValueObjects
{
    [ComplexType]
    public record NombreApellido
    {
        public string Nombre { get; init; }
        public string PrimerApellido { get; init; }
        public string? SegundoApellido { get; init; }

        public NombreApellido(string nombre, string primerApellido, string? segundoApellido = null)
        {
            Nombre = nombre;
            PrimerApellido = primerApellido;
            SegundoApellido = segundoApellido;
        }
    }
}
