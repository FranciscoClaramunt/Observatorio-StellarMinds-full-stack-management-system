﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades.ValueObjects
{
    [ComplexType]
    public record Direccion
    {
        public string Calle { get; init; }
        public string Numero { get; init; }
        public string? Esquina { get; init; }

        public Direccion(string calle, string numero, string? esquina = null)
        {
            Calle = calle;
            Numero = numero;
            Esquina = esquina;
        }
    }

}
