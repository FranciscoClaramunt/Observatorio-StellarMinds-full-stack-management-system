﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades.ValueObjects
{
    [ComplexType]
    public record Validacion
    {
        public string Indicador { get; init; }
        public string Detalle { get; init; }

        public Validacion(string indicador, string? detalle = null)
        {
            Indicador = indicador;
            Detalle = detalle;
        }

    }
}
