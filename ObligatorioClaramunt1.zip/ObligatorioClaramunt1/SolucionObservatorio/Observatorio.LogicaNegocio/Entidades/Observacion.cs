﻿using Observatorio.LogicaNegocio.Entidades.ValueObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades
{
    public class Observacion
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public Prestamo Prestamo { get; set; }
        public ObjetoCeleste ObjetoCeleste { get; set; }
        public Validacion? Validacion { get; set; }
    }
}
