﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades
{
    public class EquipoOcular : Equipo
    {
        public int Diametro { get; set; }
        public decimal Angulo { get; set; }
    }
}
