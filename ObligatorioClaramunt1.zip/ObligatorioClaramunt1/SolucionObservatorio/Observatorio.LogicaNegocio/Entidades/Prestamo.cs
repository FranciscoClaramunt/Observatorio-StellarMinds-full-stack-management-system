﻿using Observatorio.LogicaNegocio.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.Entidades
{
    public class Prestamo
    {
        public int Id { get; set; }
        public Usuario Usuario { get; set; }
        public PrestamoEquipo Equipo { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public Estado Estado { get; set; }
        public List<Auditoria> Auditorias { get; set; }
        public List<Observacion> Observaciones { get; set; }
    }
}
