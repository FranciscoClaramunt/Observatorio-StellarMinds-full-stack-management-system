﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.Enums
{
    public enum TipoMontura
    {
        ECUATORIAL,
        ALT_AZIMUTAL,
        HIBRIDA
    }
}
