﻿using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.IRepositorios
{
    public interface IRepositorioEquipo
    {
        Equipo? FindById(int id);
        IEnumerable<Equipo> FindAll();
        IEnumerable<EquipoTelescopio> FindAllTelescopios();
        IEnumerable<EquipoMontura> FindAllMonturas();
        IEnumerable<EquipoCamara> FindAllCamaras();
        IEnumerable<EquipoOcular> FindAllOculares();
        void Add(Equipo equipo);
        void Update(Equipo equipo);
        void Delete(Equipo equipo);
        bool EstaEnPrestamo(int equipoId);
    }
}
