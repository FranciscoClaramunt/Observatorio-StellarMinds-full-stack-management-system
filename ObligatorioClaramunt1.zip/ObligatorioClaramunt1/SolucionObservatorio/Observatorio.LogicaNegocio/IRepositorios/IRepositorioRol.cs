﻿using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.IRepositorios
{
    public interface IRepositorioRol
    {
        Rol? FindById(int id);
        Rol FindByName (string nombre);
        IEnumerable<Rol> FindAll();
    }
}
