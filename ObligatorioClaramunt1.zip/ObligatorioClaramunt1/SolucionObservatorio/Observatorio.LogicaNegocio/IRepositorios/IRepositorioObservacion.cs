﻿using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.IRepositorios
{
    public interface IRepositorioObservacion
    {
        Observacion? FindById(int id);
        IEnumerable<Observacion> FindByUsuario(int usuarioId);
        void Add(Observacion observacion);
    }
}
