﻿using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.IRepositorios
{
    public interface IRepositorioObjetoCeleste
    {
        ObjetoCeleste? FindById(int id);
        IEnumerable<ObjetoCeleste> FindAll();
        IEnumerable<ObjetoCeleste> FindRanking();
    }
}
