﻿using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.IRepositorios
{
    public interface IRepositorioUsuario
    {
        Usuario? FindById(int id);
        Usuario? FindByNombreUsuario(string nombreUsuario);
        Usuario? FindByEmail(string email);
        IEnumerable<Usuario> FindAll();
        void Add(Usuario usuario);
        void Update(Usuario usuario);

    }
}
