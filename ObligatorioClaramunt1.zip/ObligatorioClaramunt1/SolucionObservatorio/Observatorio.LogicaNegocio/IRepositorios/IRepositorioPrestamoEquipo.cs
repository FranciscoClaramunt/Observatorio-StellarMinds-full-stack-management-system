﻿using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.IRepositorios
{
    public interface IRepositorioPrestamoEquipo
    {
        PrestamoEquipo? FindById(int id);
        void Add(PrestamoEquipo prestamoEquipo);
    }
}
