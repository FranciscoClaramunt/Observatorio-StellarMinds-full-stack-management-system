﻿using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.IRepositorios
{
    public interface IRepositorioAuditoria
    {
        IEnumerable<Auditoria> FindAll();
        IEnumerable<Auditoria> FindByPrestamo(int prestamoId);
        IEnumerable<Auditoria> FindByCoordinador(int usuarioId);
        void Add(Auditoria auditoria);
    }
}
