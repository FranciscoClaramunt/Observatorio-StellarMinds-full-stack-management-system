﻿using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.IRepositorios
{
    public interface IRepositorioPrestamo
    {
        Prestamo? FindById(int id);
        IEnumerable<Prestamo> FindAll();
        IEnumerable<Prestamo> FindByUsuario(int usuarioId);
        IEnumerable<Prestamo> FindActivosByUsuario(int usuarioId);
        IEnumerable<Prestamo> FindByUsuarioAndMes(int usuarioId, int mes, int anio);
        IEnumerable<Usuario> FindUsuariosByTelescopio(int telescopioId);
        void Add(Prestamo prestamo);
        void Update(Prestamo prestamo);
    }
}
