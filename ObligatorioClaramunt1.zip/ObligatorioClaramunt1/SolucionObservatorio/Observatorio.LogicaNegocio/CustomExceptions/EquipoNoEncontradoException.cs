﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.CustomExceptions
{
    public class EquipoNoEncontradoException : Exception
    {
        public EquipoNoEncontradoException(string mensaje) : base(mensaje) { }
    }
}
