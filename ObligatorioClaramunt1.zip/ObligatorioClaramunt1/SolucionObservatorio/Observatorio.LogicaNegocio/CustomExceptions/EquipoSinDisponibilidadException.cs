﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.CustomExceptions
{
    public class EquipoSinDisponibilidadException : Exception
    {
        public EquipoSinDisponibilidadException(string mensaje) : base(mensaje) { }
    }
}
