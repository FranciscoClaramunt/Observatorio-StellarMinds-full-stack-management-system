﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.CustomExceptions
{
    public class DatoVacioONuloException : Exception
    {
        public DatoVacioONuloException(string mensaje) : base(mensaje)
        {
        }
    }
}
