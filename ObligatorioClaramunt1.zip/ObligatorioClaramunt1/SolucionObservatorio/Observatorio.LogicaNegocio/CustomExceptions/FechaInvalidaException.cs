﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.CustomExceptions
{
    public class FechaInvalidaException : Exception
    {
        public FechaInvalidaException(string mensaje) : base(mensaje) { }
    }
}
