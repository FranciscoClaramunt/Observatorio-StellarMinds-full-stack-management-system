﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.CustomExceptions
{
    namespace Observatorio.LogicaNegocio.CustomExceptions
    {
        public class UsuarioYaExisteException : Exception
        {
            public UsuarioYaExisteException(string mensaje) : base(mensaje)
            {
            }
        }
    }
}
