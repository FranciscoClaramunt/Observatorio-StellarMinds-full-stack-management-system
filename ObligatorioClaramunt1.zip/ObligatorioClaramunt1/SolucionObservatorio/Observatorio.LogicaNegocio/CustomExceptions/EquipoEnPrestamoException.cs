﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.CustomExceptions
{
    public class EquipoEnPrestamoException : Exception
    {
        public EquipoEnPrestamoException(string mensaje) : base(mensaje) { }
    }
}
