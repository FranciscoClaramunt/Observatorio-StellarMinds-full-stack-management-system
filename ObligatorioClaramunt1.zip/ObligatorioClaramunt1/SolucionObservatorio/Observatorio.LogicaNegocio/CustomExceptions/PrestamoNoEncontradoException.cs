﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.CustomExceptions
{
    public class PrestamoNoEncontradoException : Exception
    {
        public PrestamoNoEncontradoException(string mensaje) : base(mensaje) { }
    }
}
