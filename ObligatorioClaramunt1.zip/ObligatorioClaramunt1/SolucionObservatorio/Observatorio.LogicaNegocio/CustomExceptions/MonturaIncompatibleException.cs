﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.CustomExceptions
{
    public class MonturaIncompatibleException : Exception
    {
        public MonturaIncompatibleException(string mensaje) : base(mensaje) { }
    }
}
