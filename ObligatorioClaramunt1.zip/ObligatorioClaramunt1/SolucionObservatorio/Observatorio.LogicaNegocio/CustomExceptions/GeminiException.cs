﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.CustomExceptions
{
    public class GeminiException : Exception
    {
        public GeminiException(string mensaje) : base(mensaje) { }
    }
}
