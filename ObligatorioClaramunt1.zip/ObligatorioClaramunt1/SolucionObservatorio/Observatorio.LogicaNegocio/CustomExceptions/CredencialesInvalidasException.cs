﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaNegocio.CustomExceptions
{
    public class CredencialesInvalidasException : Exception
    {
        public CredencialesInvalidasException(string mensaje) : base(mensaje)
        {
        }
    }
}
