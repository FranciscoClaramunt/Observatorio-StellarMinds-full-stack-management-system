using Microsoft.EntityFrameworkCore;
using Observatorio.LogicaAccesoDatos;
using Observatorio.LogicaAccesoDatos.Repositorios;
using Observatorio.LogicaDeAplicacion.CasosUso.CUAuditoria;
using Observatorio.LogicaDeAplicacion.CasosUso.CUEquipo;
using Observatorio.LogicaDeAplicacion.CasosUso.CUObjetoCeleste;
using Observatorio.LogicaDeAplicacion.CasosUso.CUObservacion;
using Observatorio.LogicaDeAplicacion.CasosUso.CUPrestamo;
using Observatorio.LogicaDeAplicacion.CasosUso.CURol;
using Observatorio.LogicaDeAplicacion.CasosUso.CUUsuario;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUAuditoria;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUEquipo;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUObjetoCeleste;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUObservacion;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUPrestamo;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICURol;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUUsuario;
using Observatorio.LogicaNegocio.IRepositorios;

var builder = WebApplication.CreateBuilder(args);


// DB
// ----
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));


// REPOSITORIOS
// -------------
builder.Services.AddScoped<IRepositorioUsuario, RepositorioUsuario>();
builder.Services.AddScoped<IRepositorioRol, RepositorioRol>();
builder.Services.AddScoped<IRepositorioEquipo, RepositorioEquipo>();
builder.Services.AddScoped<IRepositorioPrestamoEquipo, RepositorioPrestamoEquipo>();
builder.Services.AddScoped<IRepositorioPrestamo, RepositorioPrestamo>();
builder.Services.AddScoped<IRepositorioAuditoria, RepositorioAuditoria>();
builder.Services.AddScoped<IRepositorioObjetoCeleste, RepositorioObjetoCeleste>();
builder.Services.AddScoped<IRepositorioObservacion, RepositorioObservacion>();

//CASOS DE USO
builder.Services.AddScoped<ICUAltaSocio, CUAltaSocio>();
builder.Services.AddScoped<ICULogin, CULogin>();
builder.Services.AddScoped<ICUAltaSocio, CUAltaSocio>();
builder.Services.AddScoped<ICUAltaEquipo, CUAltaEquipo>();
builder.Services.AddScoped<ICUListarEquipos, CUListarEquipos>();
builder.Services.AddScoped<ICUEditarEquipo, CUEditarEquipo>();
builder.Services.AddScoped<ICUEliminarEquipo, CUEliminarEquipo>();
builder.Services.AddScoped<ICUConsultarDisponibilidad, CUConsultarDisponibilidad>();
builder.Services.AddScoped<ICUAltaPrestamo, CUAltaPrestamo>();
builder.Services.AddScoped<ICUDevolucionPrestamo, CUDevolucionPrestamo>();
builder.Services.AddScoped<ICUListarPrestamos, CUListarPrestamos>();
builder.Services.AddScoped<ICUAltaObservacion, CUAltaObservacion>();
builder.Services.AddScoped<ICUValidarEquipo, CUValidarEquipo>();
builder.Services.AddScoped<ICUListarObjetosCelestes, CUListarObjetosCelestes>();
builder.Services.AddScoped<ICUListarPrestamosPorMes, CUListarPrestamosPorMes>();
builder.Services.AddScoped<ICUListarUsuariosPorTelescopio, CUListarUsuariosPorTelescopio>();
builder.Services.AddScoped<ICURankingObjetosCelestes, CURankingObjetosCelestes>();
builder.Services.AddScoped<ICUListarAuditorias, CUListarAuditorias>();
builder.Services.AddScoped<ICUListarUsuarios, CUListarUsuarios>();
builder.Services.AddScoped<ICUListarRoles, CUListarRoles>();
builder.Services.AddScoped<ICUObtenerPrestamo, CUObtenerPrestamo>();

// GEMINI SERVICE
// -------------------------
string geminiApiKey = builder.Configuration["GeminiApiKey"]
    ?? throw new Exception("GeminiApiKey no configurada");
builder.Services.AddScoped<IGeminiService>(_ => new GeminiService(geminiApiKey));

// CONTROLLERS + SWAGGER
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowMVC", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build(); // ← only once, after ALL service registrations

// MIDDLEWARE
app.UseSwagger();
app.UseSwaggerUI();
app.UseHttpsRedirection();
app.UseCors("AllowMVC");
app.UseAuthorization();
app.MapControllers();
app.Run();