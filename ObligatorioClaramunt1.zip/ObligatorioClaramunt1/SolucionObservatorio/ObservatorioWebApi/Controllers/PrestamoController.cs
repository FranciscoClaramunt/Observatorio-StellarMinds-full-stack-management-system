﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Observatorio.DTOs.DataTransferObjects.DTOsPrestamo;
using Observatorio.LogicaDeAplicacion.CasosUso.CUPrestamo;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUPrestamo;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUUsuario;
using Observatorio.LogicaNegocio.CustomExceptions;
using System.Drawing;

namespace Observatorio.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PrestamoController : ControllerBase
    {
        private readonly ICUAltaPrestamo _CUAltaPrestamo;
        private readonly ICUDevolucionPrestamo _CUDevolucionPrestamo;
        private readonly ICUListarPrestamos _CUListarPrestamos;
        private readonly ICUConsultarDisponibilidad _CUConsultarDisponibilidad;
        private readonly ICUListarPrestamosPorMes _CUListarPrestamosPorMes;
        private readonly ICUListarUsuariosPorTelescopio _CUListarUsuariosPorTelescopio;
        private readonly ICUObtenerPrestamo _CUObtenerPrestamo;

        public PrestamoController(
            ICUAltaPrestamo CUAltaPrestamo,
            ICUDevolucionPrestamo CUDevolucionPrestamo,
            ICUListarPrestamos CUListarPrestamos,
            ICUConsultarDisponibilidad CUConsultarDisponibilidad,
            ICUListarPrestamosPorMes CUListarPrestamosPorMes,
            ICUListarUsuariosPorTelescopio CUListarUsuariosPorTelescopio,
            ICUObtenerPrestamo CUObtenerPrestamo)
        {
            _CUAltaPrestamo = CUAltaPrestamo;
            _CUDevolucionPrestamo = CUDevolucionPrestamo;
            _CUListarPrestamos = CUListarPrestamos;
            _CUConsultarDisponibilidad = CUConsultarDisponibilidad;
            _CUListarPrestamosPorMes = CUListarPrestamosPorMes;
            _CUListarUsuariosPorTelescopio = CUListarUsuariosPorTelescopio;
            _CUObtenerPrestamo = CUObtenerPrestamo;
        }
    
        // Para usar en RF05
        [HttpGet("activos/{usuarioId}")]
        public IActionResult GetActivosByUsuario(int usuarioId)
        {
            try
            {
                return StatusCode(200, _CUListarPrestamos.GetActivosByUsuario(usuarioId));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        // Para usar en RF04
        [HttpGet("disponibilidad/{equipoId}")]
        public IActionResult GetDisponibilidad(int equipoId)
        {
            try
            {
                return StatusCode(200, _CUConsultarDisponibilidad.Ejecutar(equipoId));
            }
            catch (EquipoNoEncontradoException ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("{coordinadorId}")]
        public IActionResult Create(DTOAltaPrestamo dto, int coordinadorId)
        {
            try
            {
                _CUAltaPrestamo.Ejecutar(dto, coordinadorId);
                return StatusCode(201);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (EquipoNoEncontradoException ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (EquipoSinDisponibilidadException ex)
            {
                return StatusCode(409, ex.Message);
            }
            catch (MonturaIncompatibleException ex)
            {
                return StatusCode(422, ex.Message);
            }
            catch (FechaInvalidaException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut("devolucion")]
        public IActionResult Devolucion(DTODevolucion dto)
        {
            try
            {
                _CUDevolucionPrestamo.Ejecutar(dto);
                return StatusCode(200);
            }
            catch (PrestamoNoEncontradoException ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        // Para usar en RF08, préstamos por mes
        [HttpGet("pormes/{usuarioId}")]
        public IActionResult GetPorMes(int usuarioId, [FromQuery] int mes, [FromQuery] int anio)
        {
            try
            {
                var result = _CUListarPrestamosPorMes.Ejecutar(usuarioId, mes, anio);
                if (!result.Any())
                    return StatusCode(404, "No se encontraron préstamos para el período indicado");
                return StatusCode(200, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        // RF09
        [HttpGet("usuariosportelescopio/{telescopioId}")]
        public IActionResult GetUsuariosPorTelescopio(int telescopioId)
        {
            try
            {
                var result = _CUListarUsuariosPorTelescopio.Ejecutar(telescopioId);
                if (!result.Any())
                    return StatusCode(404, "No se encontraron socios para este telescopio");
                return StatusCode(200, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        //RF11 Préstamos por ID
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            try
            {
                var prestamo = _CUObtenerPrestamo.Ejecutar(id);
                return StatusCode(200, prestamo);
            }
            catch (PrestamoNoEncontradoException ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
