﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Observatorio.DTOs.DataTransferObjects.DTOsEquipo;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUEquipo;
using Observatorio.LogicaNegocio.CustomExceptions;

namespace Observatorio.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EquipoController : ControllerBase
    {
        private readonly ICUAltaEquipo _CUAltaEquipo;
        private readonly ICUListarEquipos _CUListarEquipos;
        private readonly ICUEditarEquipo _CUEditarEquipo;
        private readonly ICUEliminarEquipo _CUEliminarEquipo;

        public EquipoController(
            ICUAltaEquipo CUAltaEquipo,
            ICUListarEquipos CUListarEquipos,
            ICUEditarEquipo CUEditarEquipo,
            ICUEliminarEquipo CUEliminarEquipo)
        {
            _CUAltaEquipo = CUAltaEquipo;
            _CUListarEquipos = CUListarEquipos;
            _CUEditarEquipo = CUEditarEquipo;
            _CUEliminarEquipo = CUEliminarEquipo;
        }

        [HttpGet("telescopios")]
        public IActionResult GetTelescopios()
        {
            try
            {
                return StatusCode(200, _CUListarEquipos.GetTelescopios());
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("monturas")]
        public IActionResult GetMonturas()
        {
            try
            {
                return StatusCode(200, _CUListarEquipos.GetMonturas());
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("camaras")]
        public IActionResult GetCamaras()
        {
            try
            {
                return StatusCode(200, _CUListarEquipos.GetCamaras());
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("oculares")]
        public IActionResult GetOculares()
        {
            try
            {
                return StatusCode(200, _CUListarEquipos.GetOculares());
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("telescopio")]
        public IActionResult CreateTelescopio(DTOAltaTelescopio dto)
        {
            try
            {
                _CUAltaEquipo.AltaTelescopio(dto);
                return StatusCode(201);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("montura")]
        public IActionResult CreateMontura(DTOAltaMontura dto)
        {
            try
            {
                _CUAltaEquipo.AltaMontura(dto);
                return StatusCode(201);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("camara")]
        public IActionResult CreateCamara(DTOAltaCamara dto)
        {
            try
            {
                _CUAltaEquipo.AltaCamara(dto);
                return StatusCode(201);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("ocular")]
        public IActionResult CreateOcular(DTOAltaOcular dto)
        {
            try
            {
                _CUAltaEquipo.AltaOcular(dto);
                return StatusCode(201);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut("telescopio/{id}")]
        public IActionResult UpdateTelescopio(int id, DTOAltaTelescopio dto)
        {
            try
            {
                _CUEditarEquipo.EditarTelescopio(id, dto);
                return StatusCode(200);
            }
            catch (EquipoNoEncontradoException ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut("montura/{id}")]
        public IActionResult UpdateMontura(int id, DTOAltaMontura dto)
        {
            try
            {
                _CUEditarEquipo.EditarMontura(id, dto);
                return StatusCode(200);
            }
            catch (EquipoNoEncontradoException ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut("camara/{id}")]
        public IActionResult UpdateCamara(int id, DTOAltaCamara dto)
        {
            try
            {
                _CUEditarEquipo.EditarCamara(id, dto);
                return StatusCode(200);
            }
            catch (EquipoNoEncontradoException ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut("ocular/{id}")]
        public IActionResult UpdateOcular(int id, DTOAltaOcular dto)
        {
            try
            {
                _CUEditarEquipo.EditarOcular(id, dto);
                return StatusCode(200);
            }
            catch (EquipoNoEncontradoException ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _CUEliminarEquipo.Eliminar(id);
                return StatusCode(200);
            }
            catch (EquipoNoEncontradoException ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (EquipoEnPrestamoException ex)
            {
                return StatusCode(409, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
