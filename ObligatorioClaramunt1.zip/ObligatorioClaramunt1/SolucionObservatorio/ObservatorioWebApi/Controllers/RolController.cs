﻿using Microsoft.AspNetCore.Mvc;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICURol;

[Route("api/[controller]")]
[ApiController]
public class RolController : ControllerBase
{
    private readonly ICUListarRoles _CUListarRoles;

    public RolController(ICUListarRoles CUListarRoles)
    {
        _CUListarRoles = CUListarRoles;
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        try
        {
            return StatusCode(200, _CUListarRoles.Ejecutar());
        }
        catch (Exception ex)
        {
            return StatusCode(500, ex.Message);
        }
    }
}