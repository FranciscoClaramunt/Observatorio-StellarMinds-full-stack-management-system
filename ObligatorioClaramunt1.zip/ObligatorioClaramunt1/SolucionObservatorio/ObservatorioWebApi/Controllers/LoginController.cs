﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Observatorio.DTOs.DataTransferObjects.DTOsUsuario;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUUsuario;
using Observatorio.LogicaNegocio.CustomExceptions;

namespace Observatorio.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ICULogin _CULogin;

        public LoginController(ICULogin CULogin)
        {
            _CULogin = CULogin;
        }

        [HttpPost]
        public IActionResult Login(DTOLogin dto)
        {
            try
            {
                DTOUsuarioLogueado resultado = _CULogin.Ejecutar(dto);
                return StatusCode(200, resultado);
            }
            catch (CredencialesInvalidasException ex)
            {
                return StatusCode(401, ex.Message);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
