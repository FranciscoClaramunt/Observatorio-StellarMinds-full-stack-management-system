﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUAuditoria;

namespace Observatorio.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuditoriaController : ControllerBase
    {
        private readonly ICUListarAuditorias _CUListarAuditorias;

        public AuditoriaController(ICUListarAuditorias CUListarAuditorias)
        {
            _CUListarAuditorias = CUListarAuditorias;
        }

        [HttpGet]
        public IActionResult GetAuditorias([FromQuery] int? coordinadorId)
        {
            try
            {
                var resultado = _CUListarAuditorias.Ejecutar(coordinadorId);
                if (!resultado.Any())
                    return StatusCode(404, "No se encontraron registros de auditoría");
                return StatusCode(200, resultado);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
