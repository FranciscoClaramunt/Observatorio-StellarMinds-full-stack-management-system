﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Observatorio.DTOs.DataTransferObjects.DTOsUsuario;
using Observatorio.LogicaDeAplicacion.CasosUso.CUUsuario;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUUsuario;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.CustomExceptions.Observatorio.LogicaNegocio.CustomExceptions;

namespace Observatorio.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {

        private ICUAltaSocio _CUAltaSocio;
        private ICUListarUsuarios _CUListarUsuarios;

        public UsuarioController(ICUAltaSocio CUAltaSocio, ICUListarUsuarios CUListarUsuarios)
        {
            
            _CUAltaSocio = CUAltaSocio;
            _CUListarUsuarios = CUListarUsuarios;
        }

        [HttpPost]
        public IActionResult Create(DTOAltaSocio dto)
        {
            try
            {
                _CUAltaSocio.Ejecutar(dto);
                return StatusCode(201);

            }
            catch (UsuarioYaExisteException ex)
            {
                return StatusCode(409, ex.Message);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                string mensaje = ex.Message;
                if (ex.InnerException != null)
                    mensaje += " | INNER: " + ex.InnerException.Message;

                return StatusCode(500, mensaje);
            }
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                return StatusCode(200, _CUListarUsuarios.Ejecutar());
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
