﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Observatorio.DTOs.DataTransferObjects.DTOsObservacion;
using Observatorio.LogicaDeAplicacion.CasosUso.CUObjetoCeleste;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUObjetoCeleste;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUObservacion;
using Observatorio.LogicaNegocio.CustomExceptions;

namespace Observatorio.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ObservacionController : ControllerBase
    {
        private readonly ICUAltaObservacion _CUAltaObservacion;
        private readonly ICUValidarEquipo _CUValidarEquipo;
        private readonly ICUListarObjetosCelestes _CUListarObjetosCelestes;
        private readonly ICURankingObjetosCelestes _CURankingObjetosCelestes;

        public ObservacionController(
            ICUAltaObservacion CUAltaObservacion,
            ICUValidarEquipo CUValidarEquipo,
            ICUListarObjetosCelestes CUListarObjetosCelestes,
            ICURankingObjetosCelestes CURankingObjetosCelestes)
        {
            _CUAltaObservacion = CUAltaObservacion;
            _CUValidarEquipo = CUValidarEquipo;
            _CUListarObjetosCelestes = CUListarObjetosCelestes;
            _CURankingObjetosCelestes = CURankingObjetosCelestes;
        }
    

        /*[HttpGet("modelos")]
        public IActionResult GetModelos()
        {
            string apiKey = "AQ.Ab8RN6J53YbbI-5UB7cuvawihRuVWOscPFj5tXh3c9XEtWO9Cg";
            var client = new HttpClient();
            var response = client.GetAsync($"https://generativelanguage.googleapis.com/v1beta/models?key={apiKey}").Result;
            string body = response.Content.ReadAsStringAsync().Result;
            return StatusCode(200, body);
        }*/


        [HttpGet("objetoscelestes")]
        public IActionResult GetObjetosCelestes()
        {
            try
            {
                return StatusCode(200, _CUListarObjetosCelestes.Ejecutar());
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

     
        // Cuando el usuario hace click en "Evaluar" antes de confirmar
        [HttpPost("validar")]
        public IActionResult Validar(DTOSolicitudValidacion dto)
        {
            try
            {
                DTOValidacion resultado = _CUValidarEquipo.Ejecutar(dto);
                return StatusCode(200, resultado);
            }
            catch (PrestamoNoEncontradoException ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (GeminiException ex)
            {
                return StatusCode(502, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

      
        // Cuando el usuario confirma la observación
        [HttpPost]
        public IActionResult Create(DTOAltaObservacion dto)
        {
            try
            {
                _CUAltaObservacion.Ejecutar(dto);
                return StatusCode(201);
            }
            catch (PrestamoNoEncontradoException ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (ObservacionInvalidaException ex)
            {
                return StatusCode(422, ex.Message);
            }
            catch (DatoVacioONuloException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (GeminiException ex)
            {
                return StatusCode(502, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        // RF10, para usar acá
        [HttpGet("ranking")]
        public IActionResult GetRanking()
        {
            try
            {
                var resultado = _CURankingObjetosCelestes.Ejecutar();
                if (!resultado.Any())
                    return StatusCode(404, "No hay objetos celestes observados");
                return StatusCode(200, resultado);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
