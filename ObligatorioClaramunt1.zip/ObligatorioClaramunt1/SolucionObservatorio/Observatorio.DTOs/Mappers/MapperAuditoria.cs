﻿using Observatorio.DTOs.DataTransferObjects.DTOsAuditoria;
using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.Mappers
{
    public class MapperAuditoria
    {
        public static DTOAuditoria FromAuditoriaToDTO(Auditoria a)
        {
            return new DTOAuditoria
            {
                Id = a.Id,
                PrestamoId = a.Prestamo.Id,
                NombreCoordinador = $"{a.UsuarioCoordinador.NombreCompleto.Nombre} {a.UsuarioCoordinador.NombreCompleto.PrimerApellido}",
                Fecha = a.Fecha,
                Accion = a.Accion
            };
        }
    }
}
