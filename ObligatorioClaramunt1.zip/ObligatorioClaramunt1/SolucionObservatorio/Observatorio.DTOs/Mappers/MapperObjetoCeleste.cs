﻿using Observatorio.DTOs.DataTransferObjects.DTOsObjetoCeleste;
using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.Mappers
{
    public class MapperObjetoCeleste
    {
        public static DTOObjetoCeleste FromObjetoCelesteToDTO(ObjetoCeleste oc)
        {
            return new DTOObjetoCeleste
            {
                Id = oc.Id,
                Nombre = oc.Nombre,
                Tipo = oc.Tipo,
                MagnitudAparente = oc.MagnitudAparente
            };
        }
        
        public static DTORankingObjetoCeleste FromObjetoCelesteToRanking(ObjetoCeleste oc)
        {
            return new DTORankingObjetoCeleste
            {
                Nombre = oc.Nombre,
                Tipo = oc.Tipo,
                CantidadObservaciones = oc.Observaciones.Count
            };
        }
    }
}
