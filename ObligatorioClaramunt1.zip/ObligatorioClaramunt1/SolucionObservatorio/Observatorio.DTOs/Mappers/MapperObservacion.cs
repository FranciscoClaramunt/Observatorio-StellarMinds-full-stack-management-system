﻿using Observatorio.DTOs.DataTransferObjects.DTOsObservacion;
using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.Mappers
{
    public class MapperObservacion
    {
        public static DTOObservacion FromObservacionToDTO(Observacion o)
        {
            return new DTOObservacion
            {
                Id = o.Id,
                Fecha = o.Fecha,
                NombreObjetoCeleste = o.ObjetoCeleste.Nombre,
                TipoObjetoCeleste = o.ObjetoCeleste.Tipo,
                IndicadorValidacion = o.Validacion?.Indicador ?? "",
                DetalleValidacion = o.Validacion?.Detalle
            };
        }
    }
}
