﻿using Observatorio.DTOs.DataTransferObjects.DTOsEquipo;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.Entidades.ValueObjects;
using Observatorio.LogicaNegocio.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.Mappers
{
    public class MapperEquipo
    {
        public static DTOAltaTelescopio FromTelescopioToDTO(EquipoTelescopio t)
        {
            return new DTOAltaTelescopio
            {
                Id = t.Id,
                Marca = t.MarcaModelo.Marca,
                Modelo = t.MarcaModelo.Modelo,
                CantDisponible = t.CantDisponible,
                Apertura = t.Apertura,
                RelacionFocal = t.RelacionFocal,
                DistanciaFocal = t.DistanciaFocal,
                Peso = t.Peso
            };
        }

        public static DTOAltaMontura FromMonturaToDTO(EquipoMontura m)
        {
            return new DTOAltaMontura
            {
                Id = m.Id,
                Marca = m.MarcaModelo.Marca,
                Modelo = m.MarcaModelo.Modelo,
                CantDisponible = m.CantDisponible,
                Tipo = (int)m.Tipo,
                Carga = m.Carga,
                Computarizado = m.Computarizado
            };
        }

        public static DTOAltaCamara FromCamaraToDTO(EquipoCamara c)
        {
            return new DTOAltaCamara
            {
                Id = c.Id,
                Marca = c.MarcaModelo.Marca,
                Modelo = c.MarcaModelo.Modelo,
                CantDisponible = c.CantDisponible,
                TipoCensor = (int)c.TipoCensor,
                Resolucion = c.Resolucion,
                TamanoPixel = c.TamanoPixel
            };
        }

        public static DTOAltaOcular FromOcularToDTO(EquipoOcular o)
        {
            return new DTOAltaOcular
            {
                Id = o.Id,
                Marca = o.MarcaModelo.Marca,
                Modelo = o.MarcaModelo.Modelo,
                CantDisponible = o.CantDisponible,
                Diametro = o.Diametro,
                Angulo = o.Angulo
            };
        }

        public static EquipoTelescopio FromDTOAltaToTelescopio(DTOAltaTelescopio dto)
        {
            return new EquipoTelescopio
            {
                MarcaModelo = new MarcaModelo(dto.Marca, dto.Modelo),
                CantDisponible = dto.CantDisponible,
                Apertura = dto.Apertura,
                RelacionFocal = dto.RelacionFocal,
                DistanciaFocal = dto.DistanciaFocal,
                Peso = dto.Peso
            };
        }

        public static EquipoMontura FromDTOAltaToMontura(DTOAltaMontura dto)
        {
            return new EquipoMontura
            {
                MarcaModelo = new MarcaModelo(dto.Marca, dto.Modelo),
                CantDisponible = dto.CantDisponible,
                Tipo = (TipoMontura)dto.Tipo,
                Carga = dto.Carga,
                Computarizado = dto.Computarizado
            };
        }

        public static EquipoCamara FromDTOAltaToCamara(DTOAltaCamara dto)
        {
            return new EquipoCamara
            {
                MarcaModelo = new MarcaModelo(dto.Marca, dto.Modelo),
                CantDisponible = dto.CantDisponible,
                TipoCensor = (TipoSensor)dto.TipoCensor,
                Resolucion = dto.Resolucion,
                TamanoPixel = dto.TamanoPixel
            };
        }

        public static EquipoOcular FromDTOAltaToOcular(DTOAltaOcular dto)
        {
            return new EquipoOcular
            {
                MarcaModelo = new MarcaModelo(dto.Marca, dto.Modelo),
                CantDisponible = dto.CantDisponible,
                Diametro = dto.Diametro,
                Angulo = dto.Angulo
            };
        }
    }
}
