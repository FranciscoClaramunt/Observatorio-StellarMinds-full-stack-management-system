﻿using Observatorio.DTOs.DataTransferObjects.DTOsPrestamo;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.Mappers
{
    public class MapperPrestamo
    {
        public static DTOPrestamo FromPrestamoToDTO(Prestamo p)
        {
            return new DTOPrestamo
            {
                Id = p.Id,
                NombreUsuario = p.Usuario.NombreUsuario,
                NombreCompletoUsuario = $"{p.Usuario.NombreCompleto.Nombre} {p.Usuario.NombreCompleto.PrimerApellido}",
                FechaInicio = p.FechaInicio,
                FechaFin = p.FechaFin,
                Estado = p.Estado.ToString(),
                MarcaTelescopio = p.Equipo.Telescopio.MarcaModelo.Marca,
                ModeloTelescopio = p.Equipo.Telescopio.MarcaModelo.Modelo,
                MarcaMontura = p.Equipo.Montura.MarcaModelo.Marca,
                ModeloMontura = p.Equipo.Montura.MarcaModelo.Modelo,
                MarcaCamara = p.Equipo.Camara?.MarcaModelo.Marca,
                ModeloCamara = p.Equipo.Camara?.MarcaModelo.Modelo,
                MarcaOcular = p.Equipo.Ocular?.MarcaModelo.Marca,
                ModeloOcular = p.Equipo.Ocular?.MarcaModelo.Modelo
            };
        }

        public static DTOPrestamoConAtraso FromPrestamoToDTOConAtraso(Prestamo p)
        {
            return new DTOPrestamoConAtraso
            {
                Id = p.Id,
                FechaInicio = p.FechaInicio,
                FechaFin = p.FechaFin,
                Estado = p.Estado.ToString(),
                Atrasado = p.Estado == Estado.EN_PRESTAMO && DateTime.Today > p.FechaFin,
                MarcaTelescopio = p.Equipo.Telescopio.MarcaModelo.Marca,
                ModeloTelescopio = p.Equipo.Telescopio.MarcaModelo.Modelo,
                MarcaMontura = p.Equipo.Montura.MarcaModelo.Marca,
                ModeloMontura = p.Equipo.Montura.MarcaModelo.Modelo,
                MarcaCamara = p.Equipo.Camara?.MarcaModelo.Marca,
                ModeloCamara = p.Equipo.Camara?.MarcaModelo.Modelo,
                MarcaOcular = p.Equipo.Ocular?.MarcaModelo.Marca,
                ModeloOcular = p.Equipo.Ocular?.MarcaModelo.Modelo
            };
        }
    }
}
