﻿using Observatorio.DTOs.DataTransferObjects.DTOsRol;
using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.Mappers
{
    public class MapperRol
    {
        public static DTORol FromRolToDTO(Rol rol)
        {
            return new DTORol
            {
                Id = rol.Id,
                Nombre = rol.Nombre
            };
        }
    }
}
