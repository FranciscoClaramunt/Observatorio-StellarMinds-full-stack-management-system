﻿using Observatorio.DTOs.DataTransferObjects.DTOsUsuario;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.Entidades.ValueObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.Mappers
{
    public class MapperUsuario
    {
        public static Usuario FromDTOAltaSocioToSocio(DTOAltaSocio dto)
        {
            Usuario usuario = new Usuario();
            usuario.NombreUsuario = dto.NombreUsuario;
            usuario.NombreCompleto = new NombreApellido(dto.Nombre, dto.PrimerApellido, dto.SegundoApellido);
            usuario.Direccion = new Direccion(dto.Calle, dto.Numero, dto.Esquina);
            usuario.Telefono = dto.Telefono;
            usuario.Email = dto.Email;
            usuario.Pass = dto.Pass;
            return usuario;


        }

        public static DTOUsuarioLogueado FromUsuarioToDTOUsuarioLogueado(Usuario usuario)
        {
            return new DTOUsuarioLogueado
            {
                Id = usuario.Id,
                NombreUsuario = usuario.NombreUsuario,
                NombreCompleto = $"{usuario.NombreCompleto.Nombre} {usuario.NombreCompleto.PrimerApellido}",
                Rol = usuario.Rol.Nombre
            };
        }

        public static DTOUsuarioSimple FromUsuarioToDTOSimple(Usuario u)
        {
            return new DTOUsuarioSimple
            {
                Id = u.Id,
                NombreUsuario = u.NombreUsuario,
                NombreCompleto = $"{u.NombreCompleto.Nombre} {u.NombreCompleto.PrimerApellido}",
                Email = u.Email
            };
        }
    }
}
