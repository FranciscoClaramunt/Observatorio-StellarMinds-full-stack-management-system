﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsAuditoria
{
    public class DTOAuditoria
    {
        public int Id { get; set; }
        public int PrestamoId { get; set; }
        public string NombreCoordinador { get; set; }
        public DateTime Fecha { get; set; }
        public string Accion { get; set; }
    }
}
