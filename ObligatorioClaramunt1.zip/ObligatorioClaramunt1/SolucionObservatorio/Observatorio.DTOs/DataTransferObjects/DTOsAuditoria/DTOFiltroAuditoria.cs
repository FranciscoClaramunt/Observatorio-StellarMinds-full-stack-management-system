﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsAuditoria
{
    public class DTOFiltroAuditoria
    {
        public int? UsuarioCoordinadorId { get; set; }
    }
}
