﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsRol
{
    public class DTORol
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}