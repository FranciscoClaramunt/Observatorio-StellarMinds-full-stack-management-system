﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsPrestamo
{
    public class DTOAltaPrestamo
    {
        public int UsuarioId { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public int TelescopioId { get; set; }
        public int MonturaId { get; set; }
        public int? CamaraId { get; set; }
        public int? OcularId { get; set; }
    }
}
