﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsPrestamo
{
    public class DTODevolucion
    {
        public int PrestamoId { get; set; }
        public int UsuarioCoordinadorId { get; set; }
    }
}
