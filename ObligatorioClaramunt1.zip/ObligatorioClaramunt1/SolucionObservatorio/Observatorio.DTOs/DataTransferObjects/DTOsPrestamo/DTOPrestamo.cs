﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsPrestamo
{
    public class DTOPrestamo
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string NombreCompletoUsuario { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public string Estado { get; set; }
        public string MarcaTelescopio { get; set; }
        public string ModeloTelescopio { get; set; }
        public string MarcaMontura { get; set; }
        public string ModeloMontura { get; set; }
        public string? MarcaCamara { get; set; }
        public string? ModeloCamara { get; set; }
        public string? MarcaOcular { get; set; }
        public string? ModeloOcular { get; set; }
    }
}
