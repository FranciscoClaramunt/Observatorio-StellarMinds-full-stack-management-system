﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsObjetoCeleste
{
    public class DTORankingObjetoCeleste
    {
        public string Nombre { get; set; }
        public string Tipo { get; set; }
        public int CantidadObservaciones { get; set; }
    }
}
