﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsObjetoCeleste
{
    public class DTOObjetoCeleste
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Tipo { get; set; }
        public decimal MagnitudAparente { get; set; }
    }
}
