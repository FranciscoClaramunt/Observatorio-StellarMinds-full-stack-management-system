﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsObservacion
{
    public class DTOSolicitudValidacion
    {
        public int PrestamoId { get; set; }
        public int ObjetoCelesteId { get; set; }
    }
}
