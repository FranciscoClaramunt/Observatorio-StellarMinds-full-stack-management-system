﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsObservacion
{
    public class DTOAltaObservacion
    {
        public int PrestamoId { get; set; }
        public int ObjetoCelesteId { get; set; }
        public DateTime Fecha { get; set; }
    }
}
