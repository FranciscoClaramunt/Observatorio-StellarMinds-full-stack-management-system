﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsObservacion
{
    public class DTOObservacion
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public string NombreObjetoCeleste { get; set; }
        public string TipoObjetoCeleste { get; set; }
        public string IndicadorValidacion { get; set; }
        public string? DetalleValidacion { get; set; }
    }
}
