﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsObservacion
{
    public class DTOValidacion
    {
        public string Indicador { get; set; }
        public string? Detalle { get; set; }
    }
}
