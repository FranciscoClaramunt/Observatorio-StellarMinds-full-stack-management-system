﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsUsuario
{
    public class DTOUsuarioSimple
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string NombreCompleto { get; set; }
        public string Email { get; set; }
    }
}
