﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsUsuario
{
    public class DTOLogin
    {
        public string NombreUsuario { get; set; }
        public string Pass { get; set; }
    }
}