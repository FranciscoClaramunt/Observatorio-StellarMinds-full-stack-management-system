﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsUsuario
{
    public class DTOAltaSocio
    {
        public string NombreUsuario { get; set; }
        public string Nombre { get; init; }
        public string PrimerApellido { get; init; }
        public string? SegundoApellido { get; init; }
        public string Calle { get; init; }
        public string Numero { get; init; }
        public string? Esquina { get; init; }
        public string Telefono { get; set; }
        public string Email { get; set; }
        public string Pass { get; set; }
        public int IdRol { get; set; }
    }
}
