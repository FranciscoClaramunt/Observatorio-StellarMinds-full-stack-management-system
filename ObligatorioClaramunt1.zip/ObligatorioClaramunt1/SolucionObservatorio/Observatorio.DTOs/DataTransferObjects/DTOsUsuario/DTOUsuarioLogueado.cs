﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsUsuario
{
    public class DTOUsuarioLogueado
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string NombreCompleto { get; set; }
        public string Rol { get; set; }
    }
}
