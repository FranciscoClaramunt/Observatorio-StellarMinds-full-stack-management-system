﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsEquipo
{
    public class DTOAltaMontura
    {
        public int Id { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int CantDisponible { get; set; }
        public int Tipo { get; set; }
        public decimal Carga { get; set; }
        public bool Computarizado { get; set; }
    }
}
