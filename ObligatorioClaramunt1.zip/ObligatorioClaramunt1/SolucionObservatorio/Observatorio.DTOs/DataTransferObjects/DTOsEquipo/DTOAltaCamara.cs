﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsEquipo
{
    public class DTOAltaCamara
    {
        public int Id { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int CantDisponible { get; set; }
        public int TipoCensor { get; set; } // 0=CMOS, 1=CCD
        public string Resolucion { get; set; }
        public decimal TamanoPixel { get; set; }
    }
}
