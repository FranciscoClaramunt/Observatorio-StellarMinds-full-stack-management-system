﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsEquipo
{
    public class DTOAltaOcular
    {
        public int Id { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int CantDisponible { get; set; }
        public int Diametro { get; set; }
        public decimal Angulo { get; set; }
    }
}
