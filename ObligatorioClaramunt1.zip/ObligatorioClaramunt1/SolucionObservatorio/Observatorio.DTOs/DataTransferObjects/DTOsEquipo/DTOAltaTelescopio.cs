﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.DTOs.DataTransferObjects.DTOsEquipo
{
    public class DTOAltaTelescopio
    {
        public int Id { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int CantDisponible { get; set; }
        public int Apertura { get; set; }
        public decimal RelacionFocal { get; set; }
        public int DistanciaFocal { get; set; }
        public decimal Peso { get; set; }
    }
}
