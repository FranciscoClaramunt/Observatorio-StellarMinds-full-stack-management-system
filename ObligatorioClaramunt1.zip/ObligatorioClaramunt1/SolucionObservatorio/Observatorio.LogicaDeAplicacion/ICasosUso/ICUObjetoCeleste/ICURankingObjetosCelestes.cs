﻿using Observatorio.DTOs.DataTransferObjects.DTOsObjetoCeleste;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUObjetoCeleste
{
    public interface ICURankingObjetosCelestes
    {
        IEnumerable<DTORankingObjetoCeleste> Ejecutar();
    }
}
