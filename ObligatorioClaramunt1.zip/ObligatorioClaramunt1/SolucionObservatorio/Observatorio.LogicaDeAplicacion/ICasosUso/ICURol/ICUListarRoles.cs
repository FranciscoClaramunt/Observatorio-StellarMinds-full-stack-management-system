﻿using Observatorio.DTOs.DataTransferObjects.DTOsRol;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICURol
{
    public interface ICUListarRoles
    {
        IEnumerable<DTORol> Ejecutar();
    }
}
