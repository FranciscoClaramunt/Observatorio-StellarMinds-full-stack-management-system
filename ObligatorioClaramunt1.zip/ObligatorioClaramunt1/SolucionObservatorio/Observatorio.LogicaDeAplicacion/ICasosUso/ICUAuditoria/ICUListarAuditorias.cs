﻿using Observatorio.DTOs.DataTransferObjects.DTOsAuditoria;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUAuditoria
{
    public interface ICUListarAuditorias
    {
        IEnumerable<DTOAuditoria> Ejecutar(int? coordinadorId);
    }
}
