﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUEquipo
{
    public interface ICUEliminarEquipo
    {
        void Eliminar(int id);
    }
}
