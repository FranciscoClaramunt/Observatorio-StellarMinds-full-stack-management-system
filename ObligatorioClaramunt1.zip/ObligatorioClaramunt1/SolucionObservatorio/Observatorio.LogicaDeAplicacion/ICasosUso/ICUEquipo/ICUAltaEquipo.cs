﻿using Observatorio.DTOs.DataTransferObjects.DTOsEquipo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUEquipo
{
    public interface ICUAltaEquipo
    {
        void AltaTelescopio(DTOAltaTelescopio dto);
        void AltaMontura(DTOAltaMontura dto);
        void AltaCamara(DTOAltaCamara dto);
        void AltaOcular(DTOAltaOcular dto);
    }
}
