﻿using Observatorio.DTOs.DataTransferObjects.DTOsEquipo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUEquipo
{
    public interface ICUEditarEquipo
    {
        void EditarTelescopio(int id, DTOAltaTelescopio dto);
        void EditarMontura(int id, DTOAltaMontura dto);
        void EditarCamara(int id, DTOAltaCamara dto);
        void EditarOcular(int id, DTOAltaOcular dto);
    }
}
