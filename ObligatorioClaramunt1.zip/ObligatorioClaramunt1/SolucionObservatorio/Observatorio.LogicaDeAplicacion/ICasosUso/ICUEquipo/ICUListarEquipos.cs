﻿using Observatorio.DTOs.DataTransferObjects.DTOsEquipo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUEquipo
{
    public interface ICUListarEquipos
    {
        IEnumerable<DTOAltaTelescopio> GetTelescopios();
        IEnumerable<DTOAltaMontura> GetMonturas();
        IEnumerable<DTOAltaCamara> GetCamaras();
        IEnumerable<DTOAltaOcular> GetOculares();
    }
}
