﻿using Observatorio.DTOs.DataTransferObjects.DTOsObservacion;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUObservacion
{
    public interface ICUValidarEquipo
    {
        DTOValidacion Ejecutar(DTOSolicitudValidacion dto);
    }
}
