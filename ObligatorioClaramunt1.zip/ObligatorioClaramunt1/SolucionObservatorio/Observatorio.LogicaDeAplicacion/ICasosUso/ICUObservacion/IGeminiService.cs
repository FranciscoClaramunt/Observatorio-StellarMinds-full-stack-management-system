﻿using Observatorio.DTOs.DataTransferObjects.DTOsObservacion;
using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUObservacion
{
    public interface IGeminiService
    {
        DTOValidacion ValidarEquipo(Prestamo prestamo, ObjetoCeleste objetoCeleste);
    }
}
