﻿using Observatorio.DTOs.DataTransferObjects.DTOsPrestamo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUPrestamo
{
    public interface ICUListarPrestamosPorMes
    {
        IEnumerable<DTOPrestamoConAtraso> Ejecutar(int usuarioId, int mes, int anio);
    }
}
