﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUPrestamo
{
    public interface ICUConsultarDisponibilidad
    {
        object Ejecutar(int equipoId);
    }
}
