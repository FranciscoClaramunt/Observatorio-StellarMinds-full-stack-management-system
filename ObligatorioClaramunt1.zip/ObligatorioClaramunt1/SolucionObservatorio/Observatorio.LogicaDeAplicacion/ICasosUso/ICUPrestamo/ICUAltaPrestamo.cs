﻿using Observatorio.DTOs.DataTransferObjects.DTOsPrestamo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUPrestamo
{
    public interface ICUAltaPrestamo
    {
        void Ejecutar(DTOAltaPrestamo dto, int usuarioCoordinadorId);
    }
}
