﻿using Observatorio.DTOs.DataTransferObjects.DTOsPrestamo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUPrestamo
{
    public interface ICUListarPrestamos
    {
        IEnumerable<DTOPrestamo> GetActivosByUsuario(int usuarioId);
    }
}
