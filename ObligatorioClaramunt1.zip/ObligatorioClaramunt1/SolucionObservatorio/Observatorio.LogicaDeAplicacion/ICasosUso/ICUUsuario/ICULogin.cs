﻿using Observatorio.DTOs.DataTransferObjects.DTOsUsuario;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUUsuario
{
    public interface ICULogin
    {
        public DTOUsuarioLogueado Ejecutar(DTOLogin dto);
    }
}