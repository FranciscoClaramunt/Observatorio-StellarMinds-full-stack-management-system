﻿using System;
using System.Collections.Generic;
using System.Text;
using Observatorio.DTOs.DataTransferObjects.DTOsUsuario;

namespace Observatorio.LogicaDeAplicacion.ICasosUso.ICUUsuario
{
    public interface ICUAltaSocio
    {
        public void Ejecutar(DTOAltaSocio dto);
    }
}
