﻿using Observatorio.DTOs.DataTransferObjects.DTOsAuditoria;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUAuditoria;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUAuditoria
{
    public class CUListarAuditorias : ICUListarAuditorias
    {
        private readonly IRepositorioAuditoria _repoAuditoria;
        private readonly IRepositorioUsuario _repoUsuario;

        public CUListarAuditorias(
            IRepositorioAuditoria repoAuditoria,
            IRepositorioUsuario repoUsuario)
        {
            _repoAuditoria = repoAuditoria;
            _repoUsuario = repoUsuario;
        }

        public IEnumerable<DTOAuditoria> Ejecutar(int? coordinadorId)
        {
            IEnumerable<Auditoria> auditorias;

            if (coordinadorId.HasValue)
                auditorias = _repoAuditoria.FindByCoordinador(coordinadorId.Value);
            else
                auditorias = _repoAuditoria.FindAll();

            return auditorias.Select(a => MapperAuditoria.FromAuditoriaToDTO(a));
        }
    }
}
