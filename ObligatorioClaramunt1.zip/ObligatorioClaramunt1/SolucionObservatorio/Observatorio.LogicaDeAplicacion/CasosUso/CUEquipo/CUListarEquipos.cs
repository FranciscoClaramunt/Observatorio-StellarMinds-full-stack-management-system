﻿using Observatorio.DTOs.DataTransferObjects.DTOsEquipo;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUEquipo;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUEquipo
{
    public class CUListarEquipos : ICUListarEquipos
    {
        private readonly IRepositorioEquipo _repoEquipo;

        public CUListarEquipos(IRepositorioEquipo repoEquipo)
        {
            _repoEquipo = repoEquipo;
        }

        public IEnumerable<DTOAltaTelescopio> GetTelescopios()
        {
            return _repoEquipo.FindAllTelescopios()
                .Select(t => MapperEquipo.FromTelescopioToDTO(t));
        }

        public IEnumerable<DTOAltaMontura> GetMonturas()
        {
            return _repoEquipo.FindAllMonturas()
                .Select(m => MapperEquipo.FromMonturaToDTO(m));
        }

        public IEnumerable<DTOAltaCamara> GetCamaras()
        {
            return _repoEquipo.FindAllCamaras()
                .Select(c => MapperEquipo.FromCamaraToDTO(c));
        }

        public IEnumerable<DTOAltaOcular> GetOculares()
        {
            return _repoEquipo.FindAllOculares()
                .Select(o => MapperEquipo.FromOcularToDTO(o));
        }
    }
}
