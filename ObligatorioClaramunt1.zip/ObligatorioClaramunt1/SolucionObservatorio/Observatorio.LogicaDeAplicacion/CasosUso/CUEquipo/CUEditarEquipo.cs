﻿using Observatorio.DTOs.DataTransferObjects.DTOsEquipo;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUEquipo;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.Entidades.ValueObjects;
using Observatorio.LogicaNegocio.Enums;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUEquipo
{
    public class CUEditarEquipo : ICUEditarEquipo
    {
        private readonly IRepositorioEquipo _repoEquipo;

        public CUEditarEquipo(IRepositorioEquipo repoEquipo)
        {
            _repoEquipo = repoEquipo;
        }

        public void EditarTelescopio(int id, DTOAltaTelescopio dto)
        {
            if (string.IsNullOrEmpty(dto.Marca))
                throw new DatoVacioONuloException("La marca es obligatoria");
            if (string.IsNullOrEmpty(dto.Modelo))
                throw new DatoVacioONuloException("El modelo es obligatorio");
            if (dto.CantDisponible < 0)
                throw new DatoVacioONuloException("La cantidad disponible no puede ser negativa");
            if (dto.Apertura <= 0)
                throw new DatoVacioONuloException("La apertura debe ser mayor a cero");
            if (dto.RelacionFocal <= 0)
                throw new DatoVacioONuloException("La relación focal debe ser mayor a cero");
            if (dto.DistanciaFocal <= 0)
                throw new DatoVacioONuloException("La distancia focal debe ser mayor a cero");
            if (dto.Peso <= 0)
                throw new DatoVacioONuloException("El peso debe ser mayor a cero");

            EquipoTelescopio? telescopio = _repoEquipo.FindById(id) as EquipoTelescopio;
            if (telescopio == null)
                throw new EquipoNoEncontradoException("Telescopio no encontrado");

            telescopio.MarcaModelo = new MarcaModelo(dto.Marca, dto.Modelo);
            telescopio.CantDisponible = dto.CantDisponible;
            telescopio.Apertura = dto.Apertura;
            telescopio.RelacionFocal = dto.RelacionFocal;
            telescopio.DistanciaFocal = dto.DistanciaFocal;
            telescopio.Peso = dto.Peso;

            _repoEquipo.Update(telescopio);
        }

        public void EditarMontura(int id, DTOAltaMontura dto)
        {
            if (string.IsNullOrEmpty(dto.Marca))
                throw new DatoVacioONuloException("La marca es obligatoria");
            if (string.IsNullOrEmpty(dto.Modelo))
                throw new DatoVacioONuloException("El modelo es obligatorio");
            if (dto.CantDisponible < 0)
                throw new DatoVacioONuloException("La cantidad disponible no puede ser negativa");
            if (dto.Carga <= 0)
                throw new DatoVacioONuloException("La carga debe ser mayor a cero");

            EquipoMontura? montura = _repoEquipo.FindById(id) as EquipoMontura;
            if (montura == null)
                throw new EquipoNoEncontradoException("Montura no encontrada");

            montura.MarcaModelo = new MarcaModelo(dto.Marca, dto.Modelo);
            montura.CantDisponible = dto.CantDisponible;
            montura.Tipo = (TipoMontura)dto.Tipo;
            montura.Carga = dto.Carga;
            montura.Computarizado = dto.Computarizado;

            _repoEquipo.Update(montura);
        }

        public void EditarCamara(int id, DTOAltaCamara dto)
        {
            if (string.IsNullOrEmpty(dto.Marca))
                throw new DatoVacioONuloException("La marca es obligatoria");
            if (string.IsNullOrEmpty(dto.Modelo))
                throw new DatoVacioONuloException("El modelo es obligatorio");
            if (dto.CantDisponible < 0)
                throw new DatoVacioONuloException("La cantidad disponible no puede ser negativa");
            if (string.IsNullOrEmpty(dto.Resolucion))
                throw new DatoVacioONuloException("La resolución es obligatoria");
            if (dto.TamanoPixel <= 0)
                throw new DatoVacioONuloException("El tamaño de píxel debe ser mayor a cero");

            EquipoCamara? camara = _repoEquipo.FindById(id) as EquipoCamara;
            if (camara == null)
                throw new EquipoNoEncontradoException("Cámara no encontrada");

            camara.MarcaModelo = new MarcaModelo(dto.Marca, dto.Modelo);
            camara.CantDisponible = dto.CantDisponible;
            camara.TipoCensor = (TipoSensor)dto.TipoCensor;
            camara.Resolucion = dto.Resolucion;
            camara.TamanoPixel = dto.TamanoPixel;

            _repoEquipo.Update(camara);
        }

        public void EditarOcular(int id, DTOAltaOcular dto)
        {
            if (string.IsNullOrEmpty(dto.Marca))
                throw new DatoVacioONuloException("La marca es obligatoria");
            if (string.IsNullOrEmpty(dto.Modelo))
                throw new DatoVacioONuloException("El modelo es obligatorio");
            if (dto.CantDisponible < 0)
                throw new DatoVacioONuloException("La cantidad disponible no puede ser negativa");
            if (dto.Diametro <= 0)
                throw new DatoVacioONuloException("El diámetro debe ser mayor a cero");
            if (dto.Angulo <= 0)
                throw new DatoVacioONuloException("El ángulo debe ser mayor a cero");

            EquipoOcular? ocular = _repoEquipo.FindById(id) as EquipoOcular;
            if (ocular == null)
                throw new EquipoNoEncontradoException("Ocular no encontrado");

            ocular.MarcaModelo = new MarcaModelo(dto.Marca, dto.Modelo);
            ocular.CantDisponible = dto.CantDisponible;
            ocular.Diametro = dto.Diametro;
            ocular.Angulo = dto.Angulo;

            _repoEquipo.Update(ocular);
        }
    }
}
