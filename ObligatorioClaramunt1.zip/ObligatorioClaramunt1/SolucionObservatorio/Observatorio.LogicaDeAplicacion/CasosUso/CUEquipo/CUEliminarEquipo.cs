﻿using Observatorio.LogicaDeAplicacion.ICasosUso.ICUEquipo;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUEquipo
{
    public class CUEliminarEquipo : ICUEliminarEquipo
    {
        private readonly IRepositorioEquipo _repoEquipo;

        public CUEliminarEquipo(IRepositorioEquipo repoEquipo)
        {
            _repoEquipo = repoEquipo;
        }

        public void Eliminar(int id)
        {
            Equipo? equipo = _repoEquipo.FindById(id);
            if (equipo == null)
                throw new EquipoNoEncontradoException("Equipo no encontrado");

            if (_repoEquipo.EstaEnPrestamo(id))
                throw new EquipoEnPrestamoException("No se puede eliminar un equipo que está en préstamo");

            _repoEquipo.Delete(equipo);
        }
    }
}
