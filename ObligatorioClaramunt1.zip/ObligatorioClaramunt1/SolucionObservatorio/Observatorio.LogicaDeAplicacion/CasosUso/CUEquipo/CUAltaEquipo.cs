﻿using Observatorio.DTOs.DataTransferObjects.DTOsEquipo;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUEquipo;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUEquipo
{
    public class CUAltaEquipo : ICUAltaEquipo
    {
        private readonly IRepositorioEquipo _repoEquipo;

        public CUAltaEquipo(IRepositorioEquipo repoEquipo)
        {
            _repoEquipo = repoEquipo;
        }

        public void AltaTelescopio(DTOAltaTelescopio dto)
        {
            if (string.IsNullOrEmpty(dto.Marca))
                throw new DatoVacioONuloException("La marca es obligatoria");
            if (string.IsNullOrEmpty(dto.Modelo))
                throw new DatoVacioONuloException("El modelo es obligatorio");
            if (dto.CantDisponible < 0)
                throw new DatoVacioONuloException("La cantidad disponible no puede ser negativa");
            if (dto.Apertura <= 0)
                throw new DatoVacioONuloException("La apertura debe ser mayor a cero");
            if (dto.RelacionFocal <= 0)
                throw new DatoVacioONuloException("La relación focal debe ser mayor a cero");
            if (dto.DistanciaFocal <= 0)
                throw new DatoVacioONuloException("La distancia focal debe ser mayor a cero");
            if (dto.Peso <= 0)
                throw new DatoVacioONuloException("El peso debe ser mayor a cero");

            EquipoTelescopio telescopio = MapperEquipo.FromDTOAltaToTelescopio(dto);
            _repoEquipo.Add(telescopio);
        }

        public void AltaMontura(DTOAltaMontura dto)
        {
            if (string.IsNullOrEmpty(dto.Marca))
                throw new DatoVacioONuloException("La marca es obligatoria");
            if (string.IsNullOrEmpty(dto.Modelo))
                throw new DatoVacioONuloException("El modelo es obligatorio");
            if (dto.CantDisponible < 0)
                throw new DatoVacioONuloException("La cantidad disponible no puede ser negativa");
            if (dto.Carga <= 0)
                throw new DatoVacioONuloException("La carga debe ser mayor a cero");

            EquipoMontura montura = MapperEquipo.FromDTOAltaToMontura(dto);
            _repoEquipo.Add(montura);
        }

        public void AltaCamara(DTOAltaCamara dto)
        {
            if (string.IsNullOrEmpty(dto.Marca))
                throw new DatoVacioONuloException("La marca es obligatoria");
            if (string.IsNullOrEmpty(dto.Modelo))
                throw new DatoVacioONuloException("El modelo es obligatorio");
            if (dto.CantDisponible < 0)
                throw new DatoVacioONuloException("La cantidad disponible no puede ser negativa");
            if (string.IsNullOrEmpty(dto.Resolucion))
                throw new DatoVacioONuloException("La resolución es obligatoria");
            if (dto.TamanoPixel <= 0)
                throw new DatoVacioONuloException("El tamaño de píxel debe ser mayor a cero");

            EquipoCamara camara = MapperEquipo.FromDTOAltaToCamara(dto);
            _repoEquipo.Add(camara);
        }

        public void AltaOcular(DTOAltaOcular dto)
        {
            if (string.IsNullOrEmpty(dto.Marca))
                throw new DatoVacioONuloException("La marca es obligatoria");
            if (string.IsNullOrEmpty(dto.Modelo))
                throw new DatoVacioONuloException("El modelo es obligatorio");
            if (dto.CantDisponible < 0)
                throw new DatoVacioONuloException("La cantidad disponible no puede ser negativa");
            if (dto.Diametro <= 0)
                throw new DatoVacioONuloException("El diámetro debe ser mayor a cero");
            if (dto.Angulo <= 0)
                throw new DatoVacioONuloException("El ángulo debe ser mayor a cero");

            EquipoOcular ocular = MapperEquipo.FromDTOAltaToOcular(dto);
            _repoEquipo.Add(ocular);
        }
    }
}
