﻿using Observatorio.DTOs.DataTransferObjects.DTOsUsuario;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUUsuario;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUUsuario
{
    public class CULogin : ICULogin
    {
        private readonly IRepositorioUsuario _repoUsuario;

        public CULogin(IRepositorioUsuario repoUsuario)
        {
            _repoUsuario = repoUsuario;
        }

        public DTOUsuarioLogueado Ejecutar(DTOLogin dto)
        {
            if (string.IsNullOrEmpty(dto.NombreUsuario))
                throw new DatoVacioONuloException("El nombre de usuario es obligatorio");
            if (string.IsNullOrEmpty(dto.Pass))
                throw new DatoVacioONuloException("La contraseña es obligatoria");

            Usuario? usuario = _repoUsuario.FindByNombreUsuario(dto.NombreUsuario);
            if (usuario == null)
                throw new CredencialesInvalidasException("Credenciales inválidas");

            if (!Utilidades.Crypto.Verify(dto.Pass, usuario.Pass))
                throw new CredencialesInvalidasException("Credenciales inválidas");

            return MapperUsuario.FromUsuarioToDTOUsuarioLogueado(usuario);
        }
    }
}