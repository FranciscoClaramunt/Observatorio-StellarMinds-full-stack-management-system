﻿using Observatorio.DTOs.DataTransferObjects.DTOsUsuario;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUUsuario;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.CustomExceptions.Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUUsuario
{
    public class CUAltaSocio : ICUAltaSocio
    {
        private IRepositorioUsuario _repoUsuario;
        private IRepositorioRol _repoRol;


        public CUAltaSocio(IRepositorioUsuario repoUsuario, IRepositorioRol repoRol)
        {
            _repoUsuario = repoUsuario;
            _repoRol = repoRol;

        }
        public void Ejecutar(DTOAltaSocio dto)
        {
            if (string.IsNullOrEmpty(dto.NombreUsuario))
                throw new DatoVacioONuloException("El nombre de usuario es obligatorio");
            if (string.IsNullOrEmpty(dto.Nombre))
                throw new DatoVacioONuloException("El nombre es obligatorio");
            if (string.IsNullOrEmpty(dto.PrimerApellido))
                throw new DatoVacioONuloException("El primer apellido es obligatorio");
            if (string.IsNullOrEmpty(dto.Calle))
                throw new DatoVacioONuloException("La calle es obligatoria");
            if (string.IsNullOrEmpty(dto.Numero))
                throw new DatoVacioONuloException("El número es obligatorio");
            if (string.IsNullOrEmpty(dto.Telefono))
                throw new DatoVacioONuloException("El teléfono es obligatorio");
            if (string.IsNullOrEmpty(dto.Email))
                throw new DatoVacioONuloException("El email es obligatorio");
            if (string.IsNullOrEmpty(dto.Pass))
                throw new DatoVacioONuloException("La contraseña es obligatoria");

            //VALIDAR PASS
            if (dto.Pass.Length < 8)
                throw new DatoVacioONuloException("La contraseña debe tener al menos 8 caracteres, " +
                    "al menos una mayúscula, al menos una minúscula, al menos un número, y al menos un carácter especial");
            if (!dto.Pass.Any(char.IsUpper))
                throw new DatoVacioONuloException("La contraseña debe tener al menos 8 caracteres, " +
                    "al menos una mayúscula, al menos una minúscula, al menos un número, y al menos un carácter especial");
            if (!dto.Pass.Any(char.IsLower))
                throw new DatoVacioONuloException("La contraseña debe tener al menos 8 caracteres, " +
                    "al menos una mayúscula, al menos una minúscula, al menos un número, y al menos un carácter especial");
            if (!dto.Pass.Any(char.IsDigit))
                throw new DatoVacioONuloException("La contraseña debe tener al menos 8 caracteres, " +
                    "al menos una mayúscula, al menos una minúscula, al menos un número, y al menos un carácter especial");
            if (!dto.Pass.Any(c => !char.IsLetterOrDigit(c)))
                throw new DatoVacioONuloException("La contraseña debe tener al menos 8 caracteres, " +
                    "al menos una mayúscula, al menos una minúscula, al menos un número, y al menos un carácter especial");

            Usuario? buscadoPorUsuario = _repoUsuario.FindByNombreUsuario(dto.NombreUsuario);
            if (buscadoPorUsuario != null)
            {
                throw new UsuarioYaExisteException("Ya hay un usuario con ese nombre de usuario");
            }

            Usuario? buscadoPorEmail = _repoUsuario.FindByEmail(dto.Email);
            if (buscadoPorEmail != null)
            {
                throw new UsuarioYaExisteException("Ya hay un usuario con este email");
            }

            string passHash = Utilidades.Crypto.Hash(dto.Pass);
            dto.Pass = passHash;

            Usuario nuevo = MapperUsuario.FromDTOAltaSocioToSocio(dto);
            nuevo.RolId = dto.IdRol;;

            _repoUsuario.Add(nuevo);
        }
    }
}
