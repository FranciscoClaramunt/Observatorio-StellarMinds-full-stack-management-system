﻿using Observatorio.DTOs.DataTransferObjects.DTOsUsuario;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUUsuario;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUUsuario
{
    public class CUListarUsuariosPorTelescopio : ICUListarUsuariosPorTelescopio
    {
        private readonly IRepositorioPrestamo _repoPrestamo;

        public CUListarUsuariosPorTelescopio(IRepositorioPrestamo repoPrestamo)
        {
            _repoPrestamo = repoPrestamo;
        }

        public IEnumerable<DTOUsuarioSimple> Ejecutar(int telescopioId)
        {
            return _repoPrestamo.FindUsuariosByTelescopio(telescopioId)
                .Select(u => MapperUsuario.FromUsuarioToDTOSimple(u));
        }
    }
}
