﻿using Observatorio.DTOs.DataTransferObjects.DTOsUsuario;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUUsuario;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUUsuario
{
    public class CUListarUsuarios : ICUListarUsuarios
    {
        private readonly IRepositorioUsuario _repoUsuario;

        public CUListarUsuarios(IRepositorioUsuario repoUsuario)
        {
            _repoUsuario = repoUsuario;
        }

        public IEnumerable<DTOUsuarioSimple> Ejecutar()
        {
            return _repoUsuario.FindAll()
                .Select(u => MapperUsuario.FromUsuarioToDTOSimple(u));
        }
    }
}
