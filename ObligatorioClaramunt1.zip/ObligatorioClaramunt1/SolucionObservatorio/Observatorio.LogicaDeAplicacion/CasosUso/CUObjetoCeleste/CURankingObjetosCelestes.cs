﻿using Observatorio.DTOs.DataTransferObjects.DTOsObjetoCeleste;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUObjetoCeleste;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUObjetoCeleste
{
    public class CURankingObjetosCelestes : ICURankingObjetosCelestes
    {
        private readonly IRepositorioObjetoCeleste _repoObjetoCeleste;

        public CURankingObjetosCelestes(IRepositorioObjetoCeleste repoObjetoCeleste)
        {
            _repoObjetoCeleste = repoObjetoCeleste;
        }

        public IEnumerable<DTORankingObjetoCeleste> Ejecutar()
        {
            return _repoObjetoCeleste.FindRanking()
                .Select(oc => MapperObjetoCeleste.FromObjetoCelesteToRanking(oc));
        }
    }
}
