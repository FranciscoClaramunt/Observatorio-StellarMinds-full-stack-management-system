﻿using Observatorio.DTOs.DataTransferObjects.DTOsObjetoCeleste;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUObjetoCeleste;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUObjetoCeleste
{
    public class CUListarObjetosCelestes : ICUListarObjetosCelestes
    {
        private readonly IRepositorioObjetoCeleste _repoObjetoCeleste;

        public CUListarObjetosCelestes(IRepositorioObjetoCeleste repoObjetoCeleste)
        {
            _repoObjetoCeleste = repoObjetoCeleste;
        }

        public IEnumerable<DTOObjetoCeleste> Ejecutar()
        {
            return _repoObjetoCeleste.FindAll()
                .Select(oc => MapperObjetoCeleste.FromObjetoCelesteToDTO(oc));
        }
    }
}
