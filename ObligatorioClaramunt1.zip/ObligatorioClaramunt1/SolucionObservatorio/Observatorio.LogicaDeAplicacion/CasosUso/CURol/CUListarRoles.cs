﻿using Observatorio.DTOs.DataTransferObjects.DTOsRol;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICURol;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CURol
{
    public class CUListarRoles : ICUListarRoles
    {
        private readonly IRepositorioRol _repoRol;

        public CUListarRoles(IRepositorioRol repoRol)
        {
            _repoRol = repoRol;
        }

        public IEnumerable<DTORol> Ejecutar()
        {
            return _repoRol.FindAll()
                .Select(r => MapperRol.FromRolToDTO(r));
        }
    }
}
