﻿using Observatorio.DTOs.DataTransferObjects.DTOsPrestamo;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUPrestamo;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.Enums;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUPrestamo
{
    public class CUAltaPrestamo : ICUAltaPrestamo
    {
        private readonly IRepositorioPrestamo _repoPrestamo;
        private readonly IRepositorioEquipo _repoEquipo;
        private readonly IRepositorioUsuario _repoUsuario;
        private readonly IRepositorioAuditoria _repoAuditoria;

        public CUAltaPrestamo(
            IRepositorioPrestamo repoPrestamo,
            IRepositorioEquipo repoEquipo,
            IRepositorioUsuario repoUsuario,
            IRepositorioAuditoria repoAuditoria)
        {
            _repoPrestamo = repoPrestamo;
            _repoEquipo = repoEquipo;
            _repoUsuario = repoUsuario;
            _repoAuditoria = repoAuditoria;
        }

        public void Ejecutar(DTOAltaPrestamo dto, int usuarioCoordinadorId)
        {
            // Fecha
            if (dto.FechaInicio == default)
                throw new FechaInvalidaException("La fecha de inicio es obligatoria");
            if (dto.FechaFin == default)
                throw new FechaInvalidaException("La fecha de fin es obligatoria");
            if (dto.FechaFin <= dto.FechaInicio)
                throw new FechaInvalidaException("La fecha de fin debe ser posterior a la fecha de inicio");

            // Camara vs Ocular
            if (dto.CamaraId == null && dto.OcularId == null)
                throw new DatoVacioONuloException("Debe solicitarse al menos una cámara o un ocular");
            if (dto.CamaraId != null && dto.OcularId != null)
                throw new DatoVacioONuloException("No se puede solicitar cámara y ocular al mismo tiempo");

            // Tele y montura
            EquipoTelescopio? telescopio = _repoEquipo.FindById(dto.TelescopioId) as EquipoTelescopio;
            if (telescopio == null)
                throw new EquipoNoEncontradoException("Telescopio no encontrado");

            EquipoMontura? montura = _repoEquipo.FindById(dto.MonturaId) as EquipoMontura;
            if (montura == null)
                throw new EquipoNoEncontradoException("Montura no encontrada");

            // Disponibilidad
            if (telescopio.CantDisponible == 0)
                throw new EquipoSinDisponibilidadException("El telescopio seleccionado no tiene disponibilidad");
            if (montura.CantDisponible == 0)
                throw new EquipoSinDisponibilidadException("La montura seleccionada no tiene disponibilidad");

            // Carga de la montura
            if (montura.Carga < telescopio.Peso)
                throw new MonturaIncompatibleException("La montura no soporta el peso del telescopio");

            //
            PrestamoEquipo prestamoEquipo = new PrestamoEquipo
            {
                Telescopio = telescopio,
                Montura = montura
            };

            // Préstamos con cámara
            if (dto.CamaraId != null)
            {
                EquipoCamara? camara = _repoEquipo.FindById(dto.CamaraId.Value) as EquipoCamara;
                if (camara == null)
                    throw new EquipoNoEncontradoException("Cámara no encontrada");
                if (camara.CantDisponible == 0)
                    throw new EquipoSinDisponibilidadException("La cámara seleccionada no tiene disponibilidad");

                // Ecuatorial o híbrido
                if (montura.Tipo != TipoMontura.ECUATORIAL && montura.Tipo != TipoMontura.HIBRIDA)
                    throw new MonturaIncompatibleException("Para astrofotografía la montura debe ser ecuatorial o híbrida");

                prestamoEquipo.Camara = camara;
                camara.CantDisponible--;
                _repoEquipo.Update(camara);
            }

            // Préstamos con ocular
            if (dto.OcularId != null)
            {
                EquipoOcular? ocular = _repoEquipo.FindById(dto.OcularId.Value) as EquipoOcular;
                if (ocular == null)
                    throw new EquipoNoEncontradoException("Ocular no encontrado");
                if (ocular.CantDisponible == 0)
                    throw new EquipoSinDisponibilidadException("El ocular seleccionado no tiene disponibilidad");

                prestamoEquipo.Ocular = ocular;
                ocular.CantDisponible--;
                _repoEquipo.Update(ocular);
            }

            // Usuario de préstamo
            Usuario? usuario = _repoUsuario.FindById(dto.UsuarioId);
            if (usuario == null)
                throw new DatoVacioONuloException("Usuario no encontrado");

            // Actualizar disponibilidad
            telescopio.CantDisponible--;
            _repoEquipo.Update(telescopio);
            montura.CantDisponible--;
            _repoEquipo.Update(montura);

            //
            Prestamo prestamo = new Prestamo
            {
                Usuario = usuario,
                Equipo = prestamoEquipo,
                FechaInicio = dto.FechaInicio,
                FechaFin = dto.FechaFin,
                Estado = Estado.EN_PRESTAMO,
                Auditorias = new List<Auditoria>(),
                Observaciones = new List<Observacion>()
            };

            _repoPrestamo.Add(prestamo);

            // RF06 Auditoría
            Usuario? coordinador = _repoUsuario.FindById(usuarioCoordinadorId);
            if (coordinador == null)
                throw new DatoVacioONuloException("Usuario coordinador no encontrado");

            Auditoria auditoria = new Auditoria
            {
                Prestamo = prestamo,
                UsuarioCoordinador = coordinador,
                Fecha = DateTime.Now,
                Accion = "Alta"
            };

            _repoAuditoria.Add(auditoria);
        }
    }
}
