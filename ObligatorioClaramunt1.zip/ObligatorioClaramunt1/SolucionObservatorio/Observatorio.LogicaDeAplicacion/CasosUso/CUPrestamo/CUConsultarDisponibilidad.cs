﻿using Observatorio.LogicaDeAplicacion.ICasosUso.ICUPrestamo;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUPrestamo
{
    public class CUConsultarDisponibilidad : ICUConsultarDisponibilidad
    {
        private readonly IRepositorioEquipo _repoEquipo;

        public CUConsultarDisponibilidad(IRepositorioEquipo repoEquipo)
        {
            _repoEquipo = repoEquipo;
        }

        public object Ejecutar(int equipoId)
        {
            Equipo? equipo = _repoEquipo.FindById(equipoId);
            if (equipo == null)
                throw new EquipoNoEncontradoException("Equipo no encontrado");

            return new { disponible = equipo.CantDisponible > 0, cantidad = equipo.CantDisponible };
        }
    }
}
