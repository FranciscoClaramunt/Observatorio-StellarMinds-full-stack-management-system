﻿using Observatorio.DTOs.DataTransferObjects.DTOsPrestamo;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUPrestamo;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUPrestamo
{
    public class CUListarPrestamos : ICUListarPrestamos
    {
        private readonly IRepositorioPrestamo _repoPrestamo;

        public CUListarPrestamos(IRepositorioPrestamo repoPrestamo)
        {
            _repoPrestamo = repoPrestamo;
        }

        public IEnumerable<DTOPrestamo> GetActivosByUsuario(int usuarioId)
        {
            return _repoPrestamo.FindActivosByUsuario(usuarioId)
                .Select(p => MapperPrestamo.FromPrestamoToDTO(p));
        }
    }
}
