﻿using Observatorio.DTOs.DataTransferObjects.DTOsPrestamo;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUPrestamo;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.Enums;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUPrestamo
{
    public class CUDevolucionPrestamo : ICUDevolucionPrestamo
    {
        private readonly IRepositorioPrestamo _repoPrestamo;
        private readonly IRepositorioEquipo _repoEquipo;
        private readonly IRepositorioUsuario _repoUsuario;
        private readonly IRepositorioAuditoria _repoAuditoria;

        public CUDevolucionPrestamo(
            IRepositorioPrestamo repoPrestamo,
            IRepositorioEquipo repoEquipo,
            IRepositorioUsuario repoUsuario,
            IRepositorioAuditoria repoAuditoria)
        {
            _repoPrestamo = repoPrestamo;
            _repoEquipo = repoEquipo;
            _repoUsuario = repoUsuario;
            _repoAuditoria = repoAuditoria;
        }

        public void Ejecutar(DTODevolucion dto)
        {
            Prestamo? prestamo = _repoPrestamo.FindById(dto.PrestamoId);
            if (prestamo == null)
                throw new PrestamoNoEncontradoException("Préstamo no encontrado");

            if (prestamo.Estado == Estado.DEVUELTO)
                throw new PrestamoNoEncontradoException("El préstamo ya fue devuelto");

            // Reponer stock disponible
            prestamo.Equipo.Telescopio.CantDisponible++;
            _repoEquipo.Update(prestamo.Equipo.Telescopio);

            prestamo.Equipo.Montura.CantDisponible++;
            _repoEquipo.Update(prestamo.Equipo.Montura);

            if (prestamo.Equipo.Camara != null)
            {
                prestamo.Equipo.Camara.CantDisponible++;
                _repoEquipo.Update(prestamo.Equipo.Camara);
            }

            if (prestamo.Equipo.Ocular != null)
            {
                prestamo.Equipo.Ocular.CantDisponible++;
                _repoEquipo.Update(prestamo.Equipo.Ocular);
            }

            // Actualizar estatus del préstamo
            prestamo.Estado = Estado.DEVUELTO;
            _repoPrestamo.Update(prestamo);

            // RF06 - Auditoría
            Usuario? coordinador = _repoUsuario.FindById(dto.UsuarioCoordinadorId);
            if (coordinador == null)
                throw new DatoVacioONuloException("Usuario coordinador no encontrado");

            Auditoria auditoria = new Auditoria
            {
                Prestamo = prestamo,
                UsuarioCoordinador = coordinador,
                Fecha = DateTime.Now,
                Accion = "Devolucion"
            };

            _repoAuditoria.Add(auditoria);
        }
    }
}
