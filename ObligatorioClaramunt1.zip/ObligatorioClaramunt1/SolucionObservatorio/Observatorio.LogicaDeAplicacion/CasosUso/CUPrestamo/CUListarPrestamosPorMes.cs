﻿using Observatorio.DTOs.DataTransferObjects.DTOsPrestamo;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUPrestamo;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUPrestamo
{
    public class CUListarPrestamosPorMes : ICUListarPrestamosPorMes
    {
        private readonly IRepositorioPrestamo _repoPrestamo;

        public CUListarPrestamosPorMes(IRepositorioPrestamo repoPrestamo)
        {
            _repoPrestamo = repoPrestamo;
        }

        public IEnumerable<DTOPrestamoConAtraso> Ejecutar(int usuarioId, int mes, int anio)
        {
            var prestamos = _repoPrestamo.FindByUsuarioAndMes(usuarioId, mes, anio);
            return prestamos.Select(p => MapperPrestamo.FromPrestamoToDTOConAtraso(p));
        }
    }
}
