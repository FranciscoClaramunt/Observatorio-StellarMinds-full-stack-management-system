﻿using Observatorio.DTOs.DataTransferObjects.DTOsPrestamo;
using Observatorio.DTOs.Mappers;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUPrestamo;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUPrestamo
{

    public class CUObtenerPrestamo : ICUObtenerPrestamo
    {
        private readonly IRepositorioPrestamo _repoPrestamo;

        public CUObtenerPrestamo(IRepositorioPrestamo repoPrestamo)
        {
            _repoPrestamo = repoPrestamo;
        }

        public DTOPrestamo Ejecutar(int id)
        {
            Prestamo? prestamo = _repoPrestamo.FindById(id);
            if (prestamo == null)
                throw new PrestamoNoEncontradoException("Préstamo no encontrado");

            return MapperPrestamo.FromPrestamoToDTO(prestamo);
        }
    }
}
