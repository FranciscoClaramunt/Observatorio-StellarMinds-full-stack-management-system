﻿using Observatorio.DTOs.DataTransferObjects.DTOsObservacion;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUObservacion;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUObservacion
{
    
    public class CUValidarEquipo : ICUValidarEquipo
    {
        private readonly IRepositorioPrestamo _repoPrestamo;
        private readonly IRepositorioObjetoCeleste _repoObjetoCeleste;
        private readonly IGeminiService _geminiService;

        public CUValidarEquipo(
            IRepositorioPrestamo repoPrestamo,
            IRepositorioObjetoCeleste repoObjetoCeleste,
            IGeminiService geminiService)
        {
            _repoPrestamo = repoPrestamo;
            _repoObjetoCeleste = repoObjetoCeleste;
            _geminiService = geminiService;
        }

        public DTOValidacion Ejecutar(DTOSolicitudValidacion dto)
        {
            Prestamo? prestamo = _repoPrestamo.FindById(dto.PrestamoId);
            if (prestamo == null)
                throw new PrestamoNoEncontradoException("Préstamo no encontrado");

            ObjetoCeleste? objetoCeleste = _repoObjetoCeleste.FindById(dto.ObjetoCelesteId);
            if (objetoCeleste == null)
                throw new DatoVacioONuloException("Objeto celeste no encontrado");

            return _geminiService.ValidarEquipo(prestamo, objetoCeleste);
        }
    }
}
