﻿using Observatorio.DTOs.DataTransferObjects.DTOsObservacion;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUObservacion;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUObservacion
{
    public class GeminiService : IGeminiService
    {
        private readonly string _apiKey;
        private readonly HttpClient _httpClient;

        public GeminiService(string apiKey)
        {
            _apiKey = apiKey;
            _httpClient = new HttpClient();
        }

        public DTOValidacion ValidarEquipo(Prestamo prestamo, ObjetoCeleste objetoCeleste)
        {
            string json = BuildJson(prestamo, objetoCeleste);
            string prompt = $@"Eres un experto en astronomía y astrofotografía. 
                            Analiza si el siguiente equipo es adecuado para observar el objeto celeste indicado.
                            Responde ÚNICAMENTE con un JSON con esta estructura exacta:
                            {{""indicador"": ""IDEAL"" | ""ADECUADO"" | ""NO RECOMENDABLE"", ""detalle"": ""motivo breve solo si no es IDEAL, máximo 300 caracteres, sino cadena vacía""}}

                            Datos del equipo y objeto:
                            {json}";

            var requestBody = new
            {
                contents = new[]
                {
                new
                {
                    parts = new[]
                    {
                        new { text = prompt }
                    }
                }
            }
            };

            string requestJson = System.Text.Json.JsonSerializer.Serialize(requestBody);
            var content = new StringContent(requestJson, Encoding.UTF8, "application/json");

            string url = $"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={_apiKey}";

            HttpResponseMessage response = _httpClient.PostAsync(url, content).Result;

            if (!response.IsSuccessStatusCode)
            throw new GeminiException("Error al conectar con el servicio de Gemini");

            /*if (!response.IsSuccessStatusCode)
            {
                string errorBody = response.Content.ReadAsStringAsync().Result;
                throw new GeminiException($"Error Gemini {(int)response.StatusCode}: {errorBody}");
            }*/
            string responseJson = response.Content.ReadAsStringAsync().Result;

            using JsonDocument doc = JsonDocument.Parse(responseJson);
            string text = doc.RootElement
                .GetProperty("candidates")[0]
                .GetProperty("content")
                .GetProperty("parts")[0]
                .GetProperty("text")
                .GetString() ?? "";

            // Traducido a texto
            text = text.Replace("```json", "").Replace("```", "").Trim();

            using JsonDocument resultDoc = JsonDocument.Parse(text);
            string indicador = resultDoc.RootElement.GetProperty("indicador").GetString() ?? "NO RECOMENDABLE";
            string detalle = resultDoc.RootElement.GetProperty("detalle").GetString() ?? "";

            return new DTOValidacion
            {
                Indicador = indicador,
                Detalle = string.IsNullOrEmpty(detalle) ? null : detalle
            };
        }

        private string BuildJson(Prestamo prestamo, ObjetoCeleste objetoCeleste)
        {
            var telescopio = prestamo.Equipo.Telescopio;
            var montura = prestamo.Equipo.Montura;
            var camara = prestamo.Equipo.Camara;
            var ocular = prestamo.Equipo.Ocular;

            object equipoJson;

            if (camara != null)
            {
                equipoJson = new
                {
                    telescopio = new
                    {
                        apertura_mm = telescopio.Apertura,
                        focal_mm = telescopio.DistanciaFocal,
                        relacion_focal = telescopio.RelacionFocal
                    },
                    camara = new
                    {
                        sensor = camara.TipoCensor.ToString(),
                        resolucion_px = camara.Resolucion,
                        pixel_size_um = camara.TamanoPixel
                    },
                    objeto_celeste = new
                    {
                        nombre = objetoCeleste.Nombre,
                        tipo = objetoCeleste.Tipo
                    }
                };
            }
            else
            {
                equipoJson = new
                {
                    telescopio = new
                    {
                        apertura_mm = telescopio.Apertura,
                        focal_mm = telescopio.DistanciaFocal,
                        relacion_focal = telescopio.RelacionFocal
                    },
                    ocular = new
                    {
                        ocular_focal_mm = ocular!.Diametro,
                        campo_aparente_grados = ocular.Angulo
                    },
                    objeto_celeste = new
                    {
                        nombre = objetoCeleste.Nombre,
                        tipo = objetoCeleste.Tipo
                    }
                };
            }

            return System.Text.Json.JsonSerializer.Serialize(equipoJson);
        }
    }
}
