﻿using Observatorio.DTOs.DataTransferObjects.DTOsObservacion;
using Observatorio.LogicaDeAplicacion.ICasosUso.ICUObservacion;
using Observatorio.LogicaNegocio.CustomExceptions;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.Entidades.ValueObjects;
using Observatorio.LogicaNegocio.Enums;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaDeAplicacion.CasosUso.CUObservacion
{
 
    public class CUAltaObservacion : ICUAltaObservacion
    {
        private readonly IRepositorioObservacion _repoObservacion;
        private readonly IRepositorioPrestamo _repoPrestamo;
        private readonly IRepositorioObjetoCeleste _repoObjetoCeleste;
        private readonly IGeminiService _geminiService;

        public CUAltaObservacion(
            IRepositorioObservacion repoObservacion,
            IRepositorioPrestamo repoPrestamo,
            IRepositorioObjetoCeleste repoObjetoCeleste,
            IGeminiService geminiService)
        {
            _repoObservacion = repoObservacion;
            _repoPrestamo = repoPrestamo;
            _repoObjetoCeleste = repoObjetoCeleste;
            _geminiService = geminiService;
        }

        public void Ejecutar(DTOAltaObservacion dto)
        {
            if (dto.Fecha == default)
                throw new DatoVacioONuloException("La fecha de observación es obligatoria");

            Prestamo? prestamo = _repoPrestamo.FindById(dto.PrestamoId);
            if (prestamo == null)
                throw new PrestamoNoEncontradoException("Préstamo no encontrado");

            // Validate loan is active on observation date
            if (prestamo.Estado != Estado.EN_PRESTAMO)
                throw new ObservacionInvalidaException("El préstamo no está activo");

            if (dto.Fecha < prestamo.FechaInicio || dto.Fecha > prestamo.FechaFin)
                throw new ObservacionInvalidaException("La fecha de observación debe estar dentro del período del préstamo");

            ObjetoCeleste? objetoCeleste = _repoObjetoCeleste.FindById(dto.ObjetoCelesteId);
            if (objetoCeleste == null)
                throw new DatoVacioONuloException("Objeto celeste no encontrado");

            DTOValidacion resultado = _geminiService.ValidarEquipo(prestamo, objetoCeleste);

            Observacion observacion = new Observacion
            {
                Fecha = dto.Fecha,
                Prestamo = prestamo,
                ObjetoCeleste = objetoCeleste,
                Validacion = new Validacion(resultado.Indicador, resultado.Detalle)
            };

            _repoObservacion.Add(observacion);
        }
    }
}
