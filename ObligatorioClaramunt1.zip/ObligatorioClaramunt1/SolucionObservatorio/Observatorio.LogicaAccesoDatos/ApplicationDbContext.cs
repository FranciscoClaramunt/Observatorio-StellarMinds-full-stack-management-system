﻿using Microsoft.EntityFrameworkCore;
using Observatorio.LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaAccesoDatos
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<Rol> Roles { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Equipo> Equipos { get; set; }
        public DbSet<EquipoTelescopio> Telescopios { get; set; }
        public DbSet<EquipoMontura> Monturas { get; set; }
        public DbSet<EquipoCamara> Camaras { get; set; }
        public DbSet<EquipoOcular> Oculares { get; set; }
        public DbSet<PrestamoEquipo> PrestamosEquipo { get; set; }
        public DbSet<Prestamo> Prestamos { get; set; }
        public DbSet<Auditoria> Auditorias { get; set; }
        public DbSet<ObjetoCeleste> ObjetosCelestes { get; set; }
        public DbSet<Observacion> Observaciones { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // HERENCIAS
            // ------------
            modelBuilder.Entity<Equipo>()
                .HasDiscriminator<string>("TipoEquipo")
                .HasValue<EquipoTelescopio>("Telescopio")
                .HasValue<EquipoMontura>("Montura")
                .HasValue<EquipoCamara>("Camara")
                .HasValue<EquipoOcular>("Ocular");

            // VALUE OBJECTS
            // -------------------------

            modelBuilder.Entity<Usuario>()
                .OwnsOne(u => u.NombreCompleto, n =>
                {
                    n.Property(x => x.Nombre).IsRequired();
                    n.Property(x => x.PrimerApellido).IsRequired();
                    n.Property(x => x.SegundoApellido).IsRequired(false);
                });

            modelBuilder.Entity<Usuario>()
                .OwnsOne(u => u.Direccion, d =>
                {
                    d.Property(x => x.Calle).IsRequired();
                    d.Property(x => x.Numero).IsRequired();
                    d.Property(x => x.Esquina).IsRequired(false);
                });

            modelBuilder.Entity<Equipo>()
                .OwnsOne(e => e.MarcaModelo, m =>
                {
                    m.Property(x => x.Marca).IsRequired();
                    m.Property(x => x.Modelo).IsRequired();
                });

            modelBuilder.Entity<Observacion>()
                .OwnsOne(o => o.Validacion, v =>
                {
                    v.Property(x => x.Indicador).IsRequired();
                    v.Property(x => x.Detalle)
                        .IsRequired(false)
                        .HasMaxLength(300);
                });

            // ROL
            // ---------
            modelBuilder.Entity<Rol>()
                .HasMany(r => r.Usuarios)
                .WithOne(u => u.Rol)
                .IsRequired(true);

            // USUARIO
            // ----------
            modelBuilder.Entity<Usuario>()
                .Property(u => u.Pass)
                .IsRequired()
                .HasMaxLength(100);

            modelBuilder.Entity<Usuario>()
                .Property(u => u.Email)
                .IsRequired();

            modelBuilder.Entity<Usuario>()
                .Property(u => u.Telefono)
                .IsRequired();

            modelBuilder.Entity<Usuario>()
                .HasMany(u => u.Prestamos)
                .WithOne(p => p.Usuario)
                .IsRequired(true);

            modelBuilder.Entity<Usuario>()
                .HasMany(u => u.Auditorias)
                .WithOne(a => a.UsuarioCoordinador)
                .IsRequired(true);

            modelBuilder.Entity<Usuario>()
                 .HasIndex(u => u.NombreUsuario)
                 .IsUnique();

            // EQUIPO, subclases 
            // -------------------------

            // Telescopio
            modelBuilder.Entity<EquipoTelescopio>()
                .Property(t => t.Apertura)
                .IsRequired();

            modelBuilder.Entity<EquipoTelescopio>()
                .Property(t => t.RelacionFocal)
                .IsRequired()
                .HasPrecision(5, 2);

            modelBuilder.Entity<EquipoTelescopio>()
                .Property(t => t.DistanciaFocal)
                .IsRequired();

            modelBuilder.Entity<EquipoTelescopio>()
                .Property(t => t.Peso)
                .IsRequired()
                .HasPrecision(8, 2);

            // Montura
            modelBuilder.Entity<EquipoMontura>()
                .Property(m => m.Carga)
                .IsRequired()
                .HasPrecision(8, 2);

            // Camara
            modelBuilder.Entity<EquipoCamara>()
                .Property(c => c.Resolucion)
                .IsRequired()
                .HasMaxLength(50);

            modelBuilder.Entity<EquipoCamara>()
                .Property(c => c.TamanoPixel)
                .IsRequired()
                .HasPrecision(6, 2);

            // Ocular
            modelBuilder.Entity<EquipoOcular>()
                .Property(o => o.Angulo)
                .IsRequired()
                .HasPrecision(6, 2);


            // PRESTAMO EQUIPO
            // -------------------------
            modelBuilder.Entity<PrestamoEquipo>()
                .HasOne(pe => pe.Telescopio)
                .WithMany()
                .IsRequired(true)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<PrestamoEquipo>()
                .HasOne(pe => pe.Montura)
                .WithMany()
                .IsRequired(true)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<PrestamoEquipo>()
                .HasOne(pe => pe.Camara)
                .WithMany()
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<PrestamoEquipo>()
                .HasOne(pe => pe.Ocular)
                .WithMany()
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Restrict);


            // PRESTAMO
            // -------------------------
            modelBuilder.Entity<Prestamo>()
                .HasOne(p => p.Usuario)
                .WithMany(u => u.Prestamos)
                .IsRequired(true)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Prestamo>()
                .HasOne(p => p.Equipo)
                .WithMany()
                .IsRequired(true)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Prestamo>()
                .HasMany(p => p.Auditorias)
                .WithOne(a => a.Prestamo)
                .IsRequired(true)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Prestamo>()
                .HasMany(p => p.Observaciones)
                .WithOne(o => o.Prestamo)
                .IsRequired(true)
                .OnDelete(DeleteBehavior.Restrict);


            // AUDITORIA
            // -------------------------
            modelBuilder.Entity<Auditoria>()
                .Property(a => a.Accion)
                .IsRequired()
                .HasMaxLength(50);

            modelBuilder.Entity<Auditoria>()
                .Property(a => a.Fecha)
                .IsRequired();

            // OBJETO CELESTE
            // -------------------------
            modelBuilder.Entity<ObjetoCeleste>()
                .Property(oc => oc.Nombre)
                .IsRequired();

            modelBuilder.Entity<ObjetoCeleste>()
                .Property(oc => oc.Tipo)
                .IsRequired();

            modelBuilder.Entity<ObjetoCeleste>()
                .Property(oc => oc.MagnitudAparente)
                .HasPrecision(10, 2); // positive or negative, 2 decimal places

            modelBuilder.Entity<ObjetoCeleste>()
                .HasMany(oc => oc.Observaciones)
                .WithOne(o => o.ObjetoCeleste)
                .IsRequired(true)
                .OnDelete(DeleteBehavior.Restrict);


            // OBSERVACION
            // -------------------------
            modelBuilder.Entity<Observacion>()
                .Property(o => o.Fecha)
                .IsRequired();
        }
    }
}
