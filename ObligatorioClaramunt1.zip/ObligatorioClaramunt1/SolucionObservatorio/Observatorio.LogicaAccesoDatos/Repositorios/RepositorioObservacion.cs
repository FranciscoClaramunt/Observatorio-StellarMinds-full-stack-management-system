﻿using Microsoft.EntityFrameworkCore;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaAccesoDatos.Repositorios
{
    public class RepositorioObservacion : IRepositorioObservacion
    {
        private readonly ApplicationDbContext _context;

        public RepositorioObservacion(ApplicationDbContext context)
        {
            _context = context;

        }

        public Observacion? FindById(int id)
        {
            return _context.Observaciones
                .Include(o => o.Prestamo).ThenInclude(p => p.Usuario)
                .Include(o => o.ObjetoCeleste)
                .FirstOrDefault(o => o.Id == id);
        }

        public IEnumerable<Observacion> FindByUsuario(int usuarioId)
        {
            return _context.Observaciones
                .Include(o => o.Prestamo).ThenInclude(p => p.Usuario)
                .Include(o => o.ObjetoCeleste)
                .Where(o => o.Prestamo.Usuario.Id == usuarioId)
                .ToList();
        }

        public void Add(Observacion observacion)
        {
            _context.Observaciones.Add(observacion);
            _context.SaveChanges();
        }
    }
}
