﻿using Microsoft.EntityFrameworkCore;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaAccesoDatos.Repositorios
{
    public class RepositorioAuditoria : IRepositorioAuditoria
    {
        private readonly ApplicationDbContext _context;

        public RepositorioAuditoria(ApplicationDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Auditoria> FindAll()
        {
            return _context.Auditorias
                .Include(a => a.UsuarioCoordinador).ThenInclude(u => u.NombreCompleto)
                .Include(a => a.Prestamo)
                .ToList();
        }

        public IEnumerable<Auditoria> FindByPrestamo(int prestamoId)
        {
            return _context.Auditorias
                .Include(a => a.UsuarioCoordinador).ThenInclude(u => u.NombreCompleto)
                .Include(a => a.Prestamo)
                .Where(a => a.Prestamo.Id == prestamoId)
                .ToList();
        }

        public IEnumerable<Auditoria> FindByCoordinador(int usuarioId)
        {
            return _context.Auditorias
                .Include(a => a.UsuarioCoordinador).ThenInclude(u => u.NombreCompleto)
                .Include(a => a.Prestamo).ThenInclude(p => p.Usuario).ThenInclude(u => u.NombreCompleto)
                .Where(a => a.UsuarioCoordinador.Id == usuarioId)
                .ToList();
        }

        public void Add(Auditoria auditoria)
        {
            _context.Auditorias.Add(auditoria);
            _context.SaveChanges();
        }
    }
}
