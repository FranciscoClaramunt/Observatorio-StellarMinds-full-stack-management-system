﻿using Microsoft.EntityFrameworkCore;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaAccesoDatos.Repositorios
{
    public class RepositorioUsuario : IRepositorioUsuario
    {
        private readonly ApplicationDbContext _context;

        public RepositorioUsuario(ApplicationDbContext context)
        {
            _context = context;
        }

        public Usuario? FindById(int id)
        {
            return _context.Usuarios
                .Include(u => u.Rol)
                .Include(u => u.NombreCompleto)
                .Include(u => u.Direccion)
                .FirstOrDefault(u => u.Id == id);
        }

        public Usuario? FindByNombreUsuario(string nombreUsuario)
        {
            return _context.Usuarios
                .Include(u => u.Rol)
                .FirstOrDefault(u => u.NombreUsuario == nombreUsuario);
        }
        public Usuario? FindByEmail(string email)
        {
            return _context.Usuarios
                .Include(u => u.Rol)
                .FirstOrDefault(u => u.Email == email);
        }

        public IEnumerable<Usuario> FindAll()
        {
            return _context.Usuarios
                .Include(u => u.Rol)
                .Include(u => u.NombreCompleto)
                .Include(u => u.Direccion)
                .ToList();
        }

        public void Add(Usuario usuario)
        {
            _context.Usuarios.Add(usuario);
            _context.SaveChanges();
        }

        public void Update(Usuario usuario)
        {
            _context.Usuarios.Update(usuario);
            _context.SaveChanges();
        }
    }
}
