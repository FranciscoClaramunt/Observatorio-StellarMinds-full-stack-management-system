﻿using Microsoft.EntityFrameworkCore;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.Enums;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaAccesoDatos.Repositorios
{
    public class RepositorioEquipo : IRepositorioEquipo
    {
        private readonly ApplicationDbContext _context;

        public RepositorioEquipo(ApplicationDbContext context)
        {
            _context = context;
        }

        public Equipo? FindById(int id)
        {
            return _context.Equipos
                .Include(e => e.MarcaModelo)
                .FirstOrDefault(e => e.Id == id);
        }

        public IEnumerable<Equipo> FindAll()
        {
            return _context.Equipos
                .Include(e => e.MarcaModelo)
                .ToList();
        }

        public IEnumerable<EquipoTelescopio> FindAllTelescopios()
        {
            return _context.Telescopios
                .Include(t => t.MarcaModelo)
                .ToList();
        }

        public IEnumerable<EquipoMontura> FindAllMonturas()
        {
            return _context.Monturas
                .Include(m => m.MarcaModelo)
                .ToList();
        }

        public IEnumerable<EquipoCamara> FindAllCamaras()
        {
            return _context.Camaras
                .Include(c => c.MarcaModelo)
                .ToList();
        }

        public IEnumerable<EquipoOcular> FindAllOculares()
        {
            return _context.Oculares
                .Include(o => o.MarcaModelo)
                .ToList();
        }

        public void Add(Equipo equipo)
        {
            _context.Equipos.Add(equipo);
            _context.SaveChanges();
        }

        public void Update(Equipo equipo)
        {
            _context.Equipos.Update(equipo);
            _context.SaveChanges();
        }

        public void Delete(Equipo equipo)
        {
            _context.Equipos.Remove(equipo);
            _context.SaveChanges();
        }

        public bool EstaEnPrestamo(int equipoId)
        {
            return _context.Prestamos
                .Any(p => p.Estado == Estado.EN_PRESTAMO &&
                    (p.Equipo.Telescopio.Id == equipoId ||
                     p.Equipo.Montura.Id == equipoId ||
                     (p.Equipo.Camara != null && p.Equipo.Camara.Id == equipoId) ||
                     (p.Equipo.Ocular != null && p.Equipo.Ocular.Id == equipoId)));
        }
    }
}
