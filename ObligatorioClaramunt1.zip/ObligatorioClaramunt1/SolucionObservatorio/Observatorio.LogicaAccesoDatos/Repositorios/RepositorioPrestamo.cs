﻿using Microsoft.EntityFrameworkCore;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.Enums;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaAccesoDatos.Repositorios
{
    public class RepositorioPrestamo : IRepositorioPrestamo
    {
        private readonly ApplicationDbContext _context;

        public RepositorioPrestamo(ApplicationDbContext context)
        {
            _context = context;
        }

        public Prestamo? FindById(int id)
        {
            return _context.Prestamos
                .Include(p => p.Usuario).ThenInclude(u => u.NombreCompleto)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Telescopio).ThenInclude(t => t.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Montura).ThenInclude(m => m.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Camara!).ThenInclude(c => c.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Ocular!).ThenInclude(o => o.MarcaModelo)
                .Include(p => p.Auditorias)
                .Include(p => p.Observaciones)
                .FirstOrDefault(p => p.Id == id);
        }

        public IEnumerable<Prestamo> FindAll()
        {
            return _context.Prestamos
                .Include(p => p.Usuario).ThenInclude(u => u.NombreCompleto)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Telescopio).ThenInclude(t => t.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Montura).ThenInclude(m => m.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Camara!).ThenInclude(c => c.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Ocular!).ThenInclude(o => o.MarcaModelo)
                .ToList();
        }

        public IEnumerable<Prestamo> FindByUsuario(int usuarioId)
        {
            return _context.Prestamos
                .Include(p => p.Equipo).ThenInclude(pe => pe.Telescopio).ThenInclude(t => t.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Montura).ThenInclude(m => m.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Camara!).ThenInclude(c => c.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Ocular!).ThenInclude(o => o.MarcaModelo)
                .Where(p => p.Usuario.Id == usuarioId)
                .ToList();
        }

        public IEnumerable<Prestamo> FindActivosByUsuario(int usuarioId)
        {
            return _context.Prestamos
                .Include(p => p.Usuario)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Telescopio).ThenInclude(t => t.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Montura).ThenInclude(m => m.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Camara!).ThenInclude(c => c.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Ocular!).ThenInclude(o => o.MarcaModelo)
                .Where(p => p.Usuario.Id == usuarioId
                    && p.Estado == Estado.EN_PRESTAMO
                    && p.FechaFin >= DateTime.Today)
                .ToList();
        }

        public IEnumerable<Prestamo> FindByUsuarioAndMes(int usuarioId, int mes, int anio)
        {
            return _context.Prestamos
                .Include(p => p.Equipo).ThenInclude(pe => pe.Telescopio).ThenInclude(t => t.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Montura).ThenInclude(m => m.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Camara!).ThenInclude(c => c.MarcaModelo)
                .Include(p => p.Equipo).ThenInclude(pe => pe.Ocular!).ThenInclude(o => o.MarcaModelo)
                .Where(p => p.Usuario.Id == usuarioId
                    && p.FechaInicio.Month == mes
                    && p.FechaInicio.Year == anio)
                .ToList();
        }

        public IEnumerable<Usuario> FindUsuariosByTelescopio(int telescopioId)
        {
            return _context.Prestamos
                .Include(p => p.Usuario).ThenInclude(u => u.NombreCompleto)
                .Where(p => p.Equipo.Telescopio.Id == telescopioId)
                .Select(p => p.Usuario)
                .Distinct()
                .OrderByDescending(u => u.NombreCompleto.PrimerApellido)
                .ToList();
        }

        public void Add(Prestamo prestamo)
        {
            _context.Prestamos.Add(prestamo);
            _context.SaveChanges();
        }

        public void Update(Prestamo prestamo)
        {
            _context.Prestamos.Update(prestamo);
            _context.SaveChanges();
        }
    }
}
