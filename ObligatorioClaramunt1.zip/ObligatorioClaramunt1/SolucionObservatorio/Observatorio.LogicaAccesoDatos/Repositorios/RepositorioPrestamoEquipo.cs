﻿using Microsoft.EntityFrameworkCore;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaAccesoDatos.Repositorios
{
    public class RepositorioPrestamoEquipo : IRepositorioPrestamoEquipo
    {
        private readonly ApplicationDbContext _context;

        public RepositorioPrestamoEquipo(ApplicationDbContext context)
        {
            _context = context;
        }

        public PrestamoEquipo? FindById(int id)
        {
            return _context.PrestamosEquipo
                .Include(pe => pe.Telescopio).ThenInclude(t => t.MarcaModelo)
                .Include(pe => pe.Montura).ThenInclude(m => m.MarcaModelo)
                .Include(pe => pe.Camara).ThenInclude(c => c!.MarcaModelo)
                .Include(pe => pe.Ocular).ThenInclude(o => o!.MarcaModelo)
                .FirstOrDefault(pe => pe.Id == id);
        }

        public void Add(PrestamoEquipo prestamoEquipo)
        {
            _context.PrestamosEquipo.Add(prestamoEquipo);
            _context.SaveChanges();
        }
    }
}
