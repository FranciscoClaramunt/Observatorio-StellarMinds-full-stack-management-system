﻿using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaAccesoDatos.Repositorios
{
    public class RepositorioRol : IRepositorioRol
    {
        private readonly ApplicationDbContext _context;

        public RepositorioRol(ApplicationDbContext context)
        {
            _context = context;
        }

        public Rol? FindById(int id)
        {
            return _context.Roles
                .FirstOrDefault(r => r.Id == id);
        }

        public Rol? FindByName(string nombre)
        {
            return _context.Roles.Where(r => r.Nombre.Equals(nombre)).SingleOrDefault();
        }

        public IEnumerable<Rol> FindAll()
        {
            return _context.Roles
                .ToList();
        }
    }
}
