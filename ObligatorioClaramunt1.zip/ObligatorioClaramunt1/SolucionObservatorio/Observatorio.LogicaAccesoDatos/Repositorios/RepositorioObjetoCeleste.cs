﻿using Microsoft.EntityFrameworkCore;
using Observatorio.LogicaNegocio.Entidades;
using Observatorio.LogicaNegocio.IRepositorios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Observatorio.LogicaAccesoDatos.Repositorios
{
    public class RepositorioObjetoCeleste : IRepositorioObjetoCeleste
    {
        private readonly ApplicationDbContext _context;

        public RepositorioObjetoCeleste(ApplicationDbContext context)
        {
            _context = context;
        }

        public ObjetoCeleste? FindById(int id)
        {
            return _context.ObjetosCelestes
                .FirstOrDefault(oc => oc.Id == id);
        }

        public IEnumerable<ObjetoCeleste> FindAll()
        {
            return _context.ObjetosCelestes
                .ToList();
        }

        public IEnumerable<ObjetoCeleste> FindRanking()
        {
            return _context.ObjetosCelestes
                .Include(oc => oc.Observaciones)
                .Where(oc => oc.Observaciones.Any())
                .OrderByDescending(oc => oc.Observaciones.Count)
                .ToList();
        }
    }
}
