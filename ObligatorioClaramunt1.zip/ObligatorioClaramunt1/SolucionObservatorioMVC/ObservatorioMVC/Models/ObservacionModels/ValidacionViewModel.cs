﻿namespace ObservatorioMVC.Models.ObservacionModels
{
    public class ValidacionViewModel
    {
        public string Indicador { get; set; }
        public string? Detalle { get; set; }
    }
}
