﻿using ObservatorioMVC.Models.PrestamoModels;

namespace ObservatorioMVC.Models.ObservacionModels
{
    public class AltaObservacionViewModel
    {
        public int PrestamoId { get; set; }
        public int ObjetoCelesteId { get; set; }
        public DateTime Fecha { get; set; }

        public List<PrestamoActivoViewModel> Prestamos { get; set; } = new();
        public List<ObjetoCelesteViewModel> ObjetosCelestes { get; set; } = new();

        public string? IndicadorValidacion { get; set; }
        public string? DetalleValidacion { get; set; }
        public bool EvaluacionRealizada { get; set; } = false;

        public string? ErrorMessage { get; set; }
    }

}
