﻿namespace ObservatorioMVC.Models.EquipoModels
{
    public class ListadoEquiposViewModel
    {
        public List<AltaTelescopioViewModel> Telescopios { get; set; } = new();
        public List<AltaMonturaViewModel> Monturas { get; set; } = new();
        public List<AltaCamaraViewModel> Camaras { get; set; } = new();
        public List<AltaOcularViewModel> Oculares { get; set; } = new();
        public string? ErrorMessage { get; set; }
    }
}
