﻿namespace ObservatorioMVC.Models.EquipoModels
{
    public class AltaCamaraViewModel
    {
        public int Id { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int CantDisponible { get; set; }
        public int TipoCensor { get; set; }
        public string Resolucion { get; set; }
        public decimal TamanoPixel { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
