﻿namespace ObservatorioMVC.Models.EquipoModels
{
    public class AltaOcularViewModel
    {
        public int Id { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int CantDisponible { get; set; }
        public int Diametro { get; set; }
        public decimal Angulo { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
