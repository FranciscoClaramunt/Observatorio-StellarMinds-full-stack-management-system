﻿namespace ObservatorioMVC.Models.EquipoModels
{
    public class SeleccionTipoEquipoViewModel
    {
        public string TipoEquipo { get; set; }
    }
}
