﻿namespace ObservatorioMVC.Models.EquipoModels
{
    public class AltaMonturaViewModel
    {
        public int Id { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int CantDisponible { get; set; }
        public int Tipo { get; set; }
        public decimal Carga { get; set; }
        public bool Computarizado { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
