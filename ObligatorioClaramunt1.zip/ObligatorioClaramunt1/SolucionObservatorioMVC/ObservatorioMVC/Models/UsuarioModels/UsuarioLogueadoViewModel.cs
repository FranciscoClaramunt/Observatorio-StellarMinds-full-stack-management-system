﻿namespace ObservatorioMVC.Models.UsuarioModels
{
    public class UsuarioLogueadoViewModel
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string NombreCompleto { get; set; }
        public string Rol { get; set; }
    }
}
