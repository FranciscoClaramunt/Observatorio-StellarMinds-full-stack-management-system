﻿namespace ObservatorioMVC.Models.UsuarioModels
{
    public class RolViewModel
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}
