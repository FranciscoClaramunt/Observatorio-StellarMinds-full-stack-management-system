﻿namespace ObservatorioMVC.Models.UsuarioModels
{
    public class LoginViewModel
    {
        public string NombreUsuario { get; set; }
        public string Pass { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
