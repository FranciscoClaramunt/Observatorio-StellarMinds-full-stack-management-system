﻿namespace ObservatorioMVC.Models.UsuarioModels
{
    public class AltaSocioViewModel
    {
        public string NombreUsuario { get; set; }
        public string Nombre { get; set; }
        public string PrimerApellido { get; set; }
        public string? SegundoApellido { get; set; }
        public string Calle { get; set; }
        public string Numero { get; set; }
        public string? Esquina { get; set; }
        public string Telefono { get; set; }
        public string Email { get; set; }
        public string Pass { get; set; }
        public int IdRol { get; set; }
        public List<RolViewModel> Roles { get; set; } = new List<RolViewModel>();
        public string? ErrorMessage { get; set; }
    }
}
