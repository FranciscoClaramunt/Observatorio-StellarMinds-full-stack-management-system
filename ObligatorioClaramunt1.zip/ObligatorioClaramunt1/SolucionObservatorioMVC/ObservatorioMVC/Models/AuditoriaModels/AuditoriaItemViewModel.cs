﻿namespace ObservatorioMVC.Models.AuditoriaModels
{
    public class AuditoriaItemViewModel
    {
        public int Id { get; set; }
        public int PrestamoId { get; set; }
        public string NombreCoordinador { get; set; }
        public DateTime Fecha { get; set; }
        public string Accion { get; set; }
    }
}
