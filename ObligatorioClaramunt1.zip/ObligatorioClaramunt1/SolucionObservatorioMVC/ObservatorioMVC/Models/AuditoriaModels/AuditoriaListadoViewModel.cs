﻿using ObservatorioMVC.Models.PrestamoModels;

namespace ObservatorioMVC.Models.AuditoriaModels
{
    public class AuditoriaListadoViewModel
    {
        public int? CoordinadorId { get; set; }
        public List<AuditoriaItemViewModel> Auditorias { get; set; } = new();
        public List<UsuarioSimpleViewModel> Coordinadores { get; set; } = new();
        public string? ErrorMessage { get; set; }
    }
}
