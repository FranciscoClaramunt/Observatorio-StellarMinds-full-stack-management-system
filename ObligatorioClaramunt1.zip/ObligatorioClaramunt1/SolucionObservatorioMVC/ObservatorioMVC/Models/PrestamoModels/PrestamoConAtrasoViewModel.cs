﻿namespace ObservatorioMVC.Models.PrestamoModels
{
    public class PrestamoConAtrasoViewModel
    {
        public int Id { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public string Estado { get; set; }
        public bool Atrasado { get; set; }
        public string MarcaTelescopio { get; set; }
        public string ModeloTelescopio { get; set; }
        public string MarcaMontura { get; set; }
        public string ModeloMontura { get; set; }
        public string? MarcaCamara { get; set; }
        public string? ModeloCamara { get; set; }
        public string? MarcaOcular { get; set; }
        public string? ModeloOcular { get; set; }
    }
}
