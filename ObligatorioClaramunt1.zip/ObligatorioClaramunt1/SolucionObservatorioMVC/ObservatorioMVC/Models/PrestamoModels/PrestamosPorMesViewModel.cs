﻿namespace ObservatorioMVC.Models.PrestamoModels
{
    public class PrestamosPorMesViewModel
    {
        public int Mes { get; set; }
        public int Anio { get; set; }
        public List<PrestamoConAtrasoViewModel> Prestamos { get; set; } = new();
        public string? ErrorMessage { get; set; }
    }
}
