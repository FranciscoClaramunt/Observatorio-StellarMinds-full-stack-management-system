﻿namespace ObservatorioMVC.Models.PrestamoModels
{
    public class SeleccionPrestamoViewModel
    {
        public int PrestamoId { get; set; }
        public int UsuarioId { get; set; }
        public List<PrestamoActivoViewModel> Prestamos { get; set; } = new();
        public string? ErrorMessage { get; set; }
    }
}
