﻿using ObservatorioMVC.Models.EquipoModels;

namespace ObservatorioMVC.Models.PrestamoModels
{
    public class UsuariosPorTelescopioViewModel
    {
        public int TelescopioId { get; set; }
        public List<AltaTelescopioViewModel> Telescopios { get; set; } = new();
        public List<UsuarioSimpleViewModel> Usuarios { get; set; } = new();
        public string? NombreTelescopio { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
