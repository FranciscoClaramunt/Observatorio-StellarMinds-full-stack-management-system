﻿namespace ObservatorioMVC.Models.PrestamoModels
{
    public class DevolucionViewModel
    {
        public int UsuarioId { get; set; }
        public List<UsuarioSimpleViewModel> Socios { get; set; } = new();
        public string? ErrorMessage { get; set; }
    }
}
