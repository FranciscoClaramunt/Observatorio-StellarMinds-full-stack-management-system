﻿using ObservatorioMVC.Models.EquipoModels;

namespace ObservatorioMVC.Models.PrestamoModels
{
    public class AltaPrestamoViewModel
    {
        public int UsuarioId { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public int TelescopioId { get; set; }
        public int MonturaId { get; set; }
        public int? CamaraId { get; set; }
        public int? OcularId { get; set; }

        public List<UsuarioSimpleViewModel> Socios { get; set; } = new();
        public List<AltaTelescopioViewModel> Telescopios { get; set; } = new();
        public List<AltaMonturaViewModel> Monturas { get; set; } = new();
        public List<AltaCamaraViewModel> Camaras { get; set; } = new();
        public List<AltaOcularViewModel> Oculares { get; set; } = new();
        public string? ErrorMessage { get; set; }
    }

    public class UsuarioSimpleViewModel
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string NombreCompleto { get; set; }
        public string Email { get; set; }
    }
}
