var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// Sesion
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// HttpClient apuntando a la API
/*builder.Services.AddHttpClient("ObservatorioApi", client =>
{
    client.BaseAddress = new Uri("https://localhost:7134/");
}).ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
{
    ServerCertificateCustomValidationCallback =
        HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
});*/

builder.Services.AddHttpClient("ObservatorioApi", client =>
{
    client.BaseAddress = new Uri("http://www.observatorio-api.somee.com/");
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Auth}/{action=Login}/{id?}");

app.Run();