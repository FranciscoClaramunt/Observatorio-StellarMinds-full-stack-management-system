﻿using Microsoft.AspNetCore.Mvc;
using ObservatorioMVC.Models.UsuarioModels;

namespace ObservatorioMVC.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public UsuarioController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        private bool EsAdministrador()
        {
            return HttpContext.Session.GetString("Rol") == "Administrador";
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var response = await client.GetAsync("api/rol");
            var roles = await response.Content.ReadFromJsonAsync<List<RolViewModel>>();

            var vm = new AltaSocioViewModel { Roles = roles ?? new List<RolViewModel>() };
            return View(vm);
        }

        [HttpPost]
        public async Task<IActionResult> Create(AltaSocioViewModel vm)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");

            var dto = new
            {
                nombreUsuario = vm.NombreUsuario,
                nombre = vm.Nombre,
                primerApellido = vm.PrimerApellido,
                segundoApellido = vm.SegundoApellido,
                calle = vm.Calle,
                numero = vm.Numero,
                esquina = vm.Esquina,
                telefono = vm.Telefono,
                email = vm.Email,
                pass = vm.Pass,
                idRol = vm.IdRol
            };

            var response = await client.PostAsJsonAsync("api/usuario", dto);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Socio creado exitosamente";
                return RedirectToAction("Index", "Home");
            }

            string error = await response.Content.ReadAsStringAsync();
            vm.ErrorMessage = error;

            // Recargar roles para elegir
            var rolesResponse = await client.GetAsync("api/rol");
            vm.Roles = await rolesResponse.Content.ReadFromJsonAsync<List<RolViewModel>>()
                ?? new List<RolViewModel>();

            return View(vm);
        }
    }
}
