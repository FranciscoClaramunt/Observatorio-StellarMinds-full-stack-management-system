﻿using Microsoft.AspNetCore.Mvc;
using ObservatorioMVC.Models.EquipoModels;
using ObservatorioMVC.Models.PrestamoModels;

namespace ObservatorioMVC.Controllers
{
    public class PrestamoController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public PrestamoController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        private bool EsCoordinador()
        {
            return HttpContext.Session.GetString("Rol") == "Coordinador";
        }

        private int GetUsuarioLogueadoId()
        {
            return int.Parse(HttpContext.Session.GetString("UsuarioId") ?? "0");
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            if (!EsCoordinador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var vm = new AltaPrestamoViewModel();

            var sociosResp = await client.GetAsync("api/usuario");
            var telescopiosResp = await client.GetAsync("api/equipo/telescopios");
            var monturasResp = await client.GetAsync("api/equipo/monturas");
            var camarasResp = await client.GetAsync("api/equipo/camaras");
            var ocularesResp = await client.GetAsync("api/equipo/oculares");

            if (sociosResp.IsSuccessStatusCode)
                vm.Socios = await sociosResp.Content
                    .ReadFromJsonAsync<List<UsuarioSimpleViewModel>>() ?? new();

            if (telescopiosResp.IsSuccessStatusCode)
                vm.Telescopios = await telescopiosResp.Content
                    .ReadFromJsonAsync<List<AltaTelescopioViewModel>>() ?? new();

            if (monturasResp.IsSuccessStatusCode)
                vm.Monturas = await monturasResp.Content
                    .ReadFromJsonAsync<List<AltaMonturaViewModel>>() ?? new();

            if (camarasResp.IsSuccessStatusCode)
                vm.Camaras = await camarasResp.Content
                    .ReadFromJsonAsync<List<AltaCamaraViewModel>>() ?? new();

            if (ocularesResp.IsSuccessStatusCode)
                vm.Oculares = await ocularesResp.Content
                    .ReadFromJsonAsync<List<AltaOcularViewModel>>() ?? new();

            return View(vm);
        }

        [HttpPost]
        public async Task<IActionResult> Create(AltaPrestamoViewModel vm)
        {
            if (!EsCoordinador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            int coordinadorId = GetUsuarioLogueadoId();

            var dto = new
            {
                usuarioId = vm.UsuarioId,
                fechaInicio = vm.FechaInicio,
                fechaFin = vm.FechaFin,
                telescopioId = vm.TelescopioId,
                monturaId = vm.MonturaId,
                camaraId = vm.CamaraId,
                ocularId = vm.OcularId
            };

            var response = await client.PostAsJsonAsync(
                $"api/prestamo/{coordinadorId}", dto);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Préstamo registrado exitosamente";
                return RedirectToAction("Index", "Home");
            }

            vm.ErrorMessage = await response.Content.ReadAsStringAsync();

            // Recargar opciones para elegir
            var sociosResp = await client.GetAsync("api/usuario");
            var telescopiosResp = await client.GetAsync("api/equipo/telescopios");
            var monturasResp = await client.GetAsync("api/equipo/monturas");
            var camarasResp = await client.GetAsync("api/equipo/camaras");
            var ocularesResp = await client.GetAsync("api/equipo/oculares");

            if (sociosResp.IsSuccessStatusCode)
                vm.Socios = await sociosResp.Content
                    .ReadFromJsonAsync<List<UsuarioSimpleViewModel>>() ?? new();
            if (telescopiosResp.IsSuccessStatusCode)
                vm.Telescopios = await telescopiosResp.Content
                    .ReadFromJsonAsync<List<AltaTelescopioViewModel>>() ?? new();
            if (monturasResp.IsSuccessStatusCode)
                vm.Monturas = await monturasResp.Content
                    .ReadFromJsonAsync<List<AltaMonturaViewModel>>() ?? new();
            if (camarasResp.IsSuccessStatusCode)
                vm.Camaras = await camarasResp.Content
                    .ReadFromJsonAsync<List<AltaCamaraViewModel>>() ?? new();
            if (ocularesResp.IsSuccessStatusCode)
                vm.Oculares = await ocularesResp.Content
                    .ReadFromJsonAsync<List<AltaOcularViewModel>>() ?? new();

            return View(vm);
        }

        // RF05 Seleccionar socio
        [HttpGet]
        public async Task<IActionResult> Devolucion()
        {
            if (!EsCoordinador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var vm = new DevolucionViewModel();

            var sociosResp = await client.GetAsync("api/usuario");
            if (sociosResp.IsSuccessStatusCode)
                vm.Socios = await sociosResp.Content
                    .ReadFromJsonAsync<List<UsuarioSimpleViewModel>>() ?? new();

            return View(vm);
        }

        [HttpPost]
        public IActionResult Devolucion(DevolucionViewModel vm)
        {
            if (!EsCoordinador())
                return RedirectToAction("Login", "Auth");

            return RedirectToAction("SeleccionarPrestamo", new { usuarioId = vm.UsuarioId });
        }

        // RF05 Listar préstamos activos
        [HttpGet]
        public async Task<IActionResult> SeleccionarPrestamo(int usuarioId)
        {
            if (!EsCoordinador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var vm = new SeleccionPrestamoViewModel { UsuarioId = usuarioId };

            var response = await client.GetAsync($"api/prestamo/activos/{usuarioId}");

            if (response.IsSuccessStatusCode)
                vm.Prestamos = await response.Content
                    .ReadFromJsonAsync<List<PrestamoActivoViewModel>>() ?? new();

            if (!vm.Prestamos.Any())
                vm.ErrorMessage = "Este socio no tiene préstamos activos";

            return View(vm);
        }

        // RF05 Confirmar devolución
        [HttpPost]
        public async Task<IActionResult> ConfirmarDevolucion(int prestamoId)
        {
            if (!EsCoordinador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            int coordinadorId = GetUsuarioLogueadoId();

            var dto = new
            {
                prestamoId = prestamoId,
                usuarioCoordinadorId = coordinadorId
            };

            var response = await client.PutAsJsonAsync("api/prestamo/devolucion", dto);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Devolución registrada exitosamente";
                return RedirectToAction("Index", "Home");
            }

            TempData["ErrorMessage"] = await response.Content.ReadAsStringAsync();
            return RedirectToAction("Index", "Home");
        }

        // RF08 Mis prestamos por mes
        [HttpGet]
        public IActionResult MisPrestamos()
        {
            if (HttpContext.Session.GetString("Rol") == null)
                return RedirectToAction("Login", "Auth");

            return View(new PrestamosPorMesViewModel
            {
                Mes = DateTime.Today.Month,
                Anio = DateTime.Today.Year
            });
        }

        [HttpPost]
        public async Task<IActionResult> MisPrestamos(PrestamosPorMesViewModel vm)
        {
            if (HttpContext.Session.GetString("Rol") == null)
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            int usuarioId = GetUsuarioLogueadoId();

            var response = await client.GetAsync(
                $"api/prestamo/pormes/{usuarioId}?mes={vm.Mes}&anio={vm.Anio}");

            if (response.IsSuccessStatusCode)
                vm.Prestamos = await response.Content
                    .ReadFromJsonAsync<List<PrestamoConAtrasoViewModel>>() ?? new();
            else if ((int)response.StatusCode == 404)
                vm.ErrorMessage = "No se encontraron préstamos para el período indicado";
            else
                vm.ErrorMessage = await response.Content.ReadAsStringAsync();

            return View(vm);
        }

        // RF09 Usuarios por telescopio
        [HttpGet]
        public async Task<IActionResult> UsuariosPorTelescopio()
        {
            string? rol = HttpContext.Session.GetString("Rol");
            if (rol != "Administrador" && rol != "Coordinador")
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var vm = new UsuariosPorTelescopioViewModel();

            var resp = await client.GetAsync("api/equipo/telescopios");
            if (resp.IsSuccessStatusCode)
                vm.Telescopios = await resp.Content
                    .ReadFromJsonAsync<List<AltaTelescopioViewModel>>() ?? new();

            return View(vm);
        }

        [HttpPost]
        public async Task<IActionResult> UsuariosPorTelescopio(UsuariosPorTelescopioViewModel vm)
        {
            string? rol = HttpContext.Session.GetString("Rol");
            if (rol != "Administrador" && rol != "Coordinador")
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");

            var telescopiosResp = await client.GetAsync("api/equipo/telescopios");
            if (telescopiosResp.IsSuccessStatusCode)
                vm.Telescopios = await telescopiosResp.Content
                    .ReadFromJsonAsync<List<AltaTelescopioViewModel>>() ?? new();

            var response = await client.GetAsync(
                $"api/prestamo/usuariosportelescopio/{vm.TelescopioId}");

            if (response.IsSuccessStatusCode)
            {
                vm.Usuarios = await response.Content
                    .ReadFromJsonAsync<List<UsuarioSimpleViewModel>>() ?? new();
                var telescopio = vm.Telescopios.FirstOrDefault(t => t.Id == vm.TelescopioId);
                vm.NombreTelescopio = telescopio != null
                    ? $"{telescopio.Marca} {telescopio.Modelo}"
                    : "";
            }
            else if ((int)response.StatusCode == 404)
                vm.ErrorMessage = "No se encontraron socios para este telescopio";
            else
                vm.ErrorMessage = await response.Content.ReadAsStringAsync();

            return View(vm);
        }

        //RF11 Detalles del préstamo
        [HttpGet]
        public async Task<IActionResult> Detalle(int id)
        {
            if (HttpContext.Session.GetString("Rol") == null)
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var response = await client.GetAsync($"api/prestamo/{id}");

            if (response.IsSuccessStatusCode)
            {
                var prestamo = await response.Content
                    .ReadFromJsonAsync<PrestamoActivoViewModel>();
                return View(prestamo);
            }

            TempData["ErrorMessage"] = "Préstamo no encontrado";
            return RedirectToAction("Index", "Home");
        }
    }
}
