﻿using Microsoft.AspNetCore.Mvc;
using ObservatorioMVC.Models.EquipoModels;

namespace ObservatorioMVC.Controllers
{
    public class EquipoController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public EquipoController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        private bool EsAdministrador()
        {
            return HttpContext.Session.GetString("Rol") == "Administrador";
        }

        // RF03 - Listar todos los equipos
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var vm = new ListadoEquiposViewModel();

            var tResp = await client.GetAsync("api/equipo/telescopios");
            var mResp = await client.GetAsync("api/equipo/monturas");
            var cResp = await client.GetAsync("api/equipo/camaras");
            var oResp = await client.GetAsync("api/equipo/oculares");

            if (tResp.IsSuccessStatusCode)
                vm.Telescopios = await tResp.Content
                    .ReadFromJsonAsync<List<AltaTelescopioViewModel>>() ?? new();

            if (mResp.IsSuccessStatusCode)
                vm.Monturas = await mResp.Content
                    .ReadFromJsonAsync<List<AltaMonturaViewModel>>() ?? new();

            if (cResp.IsSuccessStatusCode)
                vm.Camaras = await cResp.Content
                    .ReadFromJsonAsync<List<AltaCamaraViewModel>>() ?? new();

            if (oResp.IsSuccessStatusCode)
                vm.Oculares = await oResp.Content
                    .ReadFromJsonAsync<List<AltaOcularViewModel>>() ?? new();

            return View(vm);
        }

        // RF03 - Elegir tipo de equipoi
        [HttpGet]
        public IActionResult SeleccionarTipo()
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            return View(new SeleccionTipoEquipoViewModel());
        }

        [HttpPost]
        public IActionResult SeleccionarTipo(SeleccionTipoEquipoViewModel vm)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            return vm.TipoEquipo switch
            {
                "Telescopio" => RedirectToAction("CreateTelescopio"),
                "Montura" => RedirectToAction("CreateMontura"),
                "Camara" => RedirectToAction("CreateCamara"),
                "Ocular" => RedirectToAction("CreateOcular"),
                _ => View(vm)
            };
        }

        // RF03 - Cargar Telescopio
        [HttpGet]
        public IActionResult CreateTelescopio()
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");
            return View(new AltaTelescopioViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> CreateTelescopio(AltaTelescopioViewModel vm)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var dto = new
            {
                marca = vm.Marca,
                modelo = vm.Modelo,
                cantDisponible = vm.CantDisponible,
                apertura = vm.Apertura,
                relacionFocal = vm.RelacionFocal,
                distanciaFocal = vm.DistanciaFocal,
                peso = vm.Peso
            };

            var response = await client.PostAsJsonAsync("api/equipo/telescopio", dto);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Telescopio creado exitosamente";
                return RedirectToAction("Index");
            }

            vm.ErrorMessage = await response.Content.ReadAsStringAsync();
            return View(vm);
        }

        // RF03 - Cargar Montura
        [HttpGet]
        public IActionResult CreateMontura()
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");
            return View(new AltaMonturaViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> CreateMontura(AltaMonturaViewModel vm)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var dto = new
            {
                marca = vm.Marca,
                modelo = vm.Modelo,
                cantDisponible = vm.CantDisponible,
                tipo = vm.Tipo,
                carga = vm.Carga,
                computarizado = vm.Computarizado
            };

            var response = await client.PostAsJsonAsync("api/equipo/montura", dto);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Montura creada exitosamente";
                return RedirectToAction("Index");
            }

            vm.ErrorMessage = await response.Content.ReadAsStringAsync();
            return View(vm);
        }

        // RF03 - Cargar Càmara
        [HttpGet]
        public IActionResult CreateCamara()
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");
            return View(new AltaCamaraViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> CreateCamara(AltaCamaraViewModel vm)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var dto = new
            {
                marca = vm.Marca,
                modelo = vm.Modelo,
                cantDisponible = vm.CantDisponible,
                tipoCensor = vm.TipoCensor,
                resolucion = vm.Resolucion,
                tamanoPixel = vm.TamanoPixel
            };

            var response = await client.PostAsJsonAsync("api/equipo/camara", dto);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Cámara creada exitosamente";
                return RedirectToAction("Index");
            }

            vm.ErrorMessage = await response.Content.ReadAsStringAsync();
            return View(vm);
        }

        // RF03 - Cargar Ocular
        [HttpGet]
        public IActionResult CreateOcular()
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");
            return View(new AltaOcularViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> CreateOcular(AltaOcularViewModel vm)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var dto = new
            {
                marca = vm.Marca,
                modelo = vm.Modelo,
                cantDisponible = vm.CantDisponible,
                diametro = vm.Diametro,
                angulo = vm.Angulo
            };

            var response = await client.PostAsJsonAsync("api/equipo/ocular", dto);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Ocular creado exitosamente";
                return RedirectToAction("Index");
            }

            vm.ErrorMessage = await response.Content.ReadAsStringAsync();
            return View(vm);
        }

        // RF03 - Eliminar
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var response = await client.DeleteAsync($"api/equipo/{id}");

            if (response.IsSuccessStatusCode)
                TempData["SuccessMessage"] = "Equipo eliminado exitosamente";
            else
            {
                string error = await response.Content.ReadAsStringAsync();
                TempData["ErrorMessage"] = error;
            }

            return RedirectToAction("Index");
        }

        // RF03 - Editar Telescopio
        [HttpGet]
        public async Task<IActionResult> EditTelescopio(int id)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var response = await client.GetAsync($"api/equipo/telescopios");
            var telescopios = await response.Content
                .ReadFromJsonAsync<List<AltaTelescopioViewModel>>() ?? new();

            var telescopio = telescopios.FirstOrDefault(t => t.Id == id);
            if (telescopio == null)
                return RedirectToAction("Index");

            return View(telescopio);
        }

        [HttpPost]
        public async Task<IActionResult> EditTelescopio(int id, AltaTelescopioViewModel vm)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var dto = new
            {
                marca = vm.Marca,
                modelo = vm.Modelo,
                cantDisponible = vm.CantDisponible,
                apertura = vm.Apertura,
                relacionFocal = vm.RelacionFocal,
                distanciaFocal = vm.DistanciaFocal,
                peso = vm.Peso
            };

            var response = await client.PutAsJsonAsync($"api/equipo/telescopio/{id}", dto);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Telescopio actualizado exitosamente";
                return RedirectToAction("Index");
            }

            vm.ErrorMessage = await response.Content.ReadAsStringAsync();
            return View(vm);
        }

        // RF03 - Editar Montura
        [HttpGet]
        public async Task<IActionResult> EditMontura(int id)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var response = await client.GetAsync("api/equipo/monturas");
            var monturas = await response.Content
                .ReadFromJsonAsync<List<AltaMonturaViewModel>>() ?? new();

            var montura = monturas.FirstOrDefault(m => m.Id == id);
            if (montura == null)
                return RedirectToAction("Index");

            return View(montura);
        }

        [HttpPost]
        public async Task<IActionResult> EditMontura(int id, AltaMonturaViewModel vm)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var dto = new
            {
                marca = vm.Marca,
                modelo = vm.Modelo,
                cantDisponible = vm.CantDisponible,
                tipo = vm.Tipo,
                carga = vm.Carga,
                computarizado = vm.Computarizado
            };

            var response = await client.PutAsJsonAsync($"api/equipo/montura/{id}", dto);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Montura actualizada exitosamente";
                return RedirectToAction("Index");
            }

            vm.ErrorMessage = await response.Content.ReadAsStringAsync();
            return View(vm);
        }

        // RF03 - Editar Càmara
        [HttpGet]
        public async Task<IActionResult> EditCamara(int id)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var response = await client.GetAsync("api/equipo/camaras");
            var camaras = await response.Content
                .ReadFromJsonAsync<List<AltaCamaraViewModel>>() ?? new();

            var camara = camaras.FirstOrDefault(c => c.Id == id);
            if (camara == null)
                return RedirectToAction("Index");

            return View(camara);
        }

        [HttpPost]
        public async Task<IActionResult> EditCamara(int id, AltaCamaraViewModel vm)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var dto = new
            {
                marca = vm.Marca,
                modelo = vm.Modelo,
                cantDisponible = vm.CantDisponible,
                tipoCensor = vm.TipoCensor,
                resolucion = vm.Resolucion,
                tamanoPixel = vm.TamanoPixel
            };

            var response = await client.PutAsJsonAsync($"api/equipo/camara/{id}", dto);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Cámara actualizada exitosamente";
                return RedirectToAction("Index");
            }

            vm.ErrorMessage = await response.Content.ReadAsStringAsync();
            return View(vm);
        }

        // RF03 - Editar Ocular
        [HttpGet]
        public async Task<IActionResult> EditOcular(int id)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var response = await client.GetAsync("api/equipo/oculares");
            var oculares = await response.Content
                .ReadFromJsonAsync<List<AltaOcularViewModel>>() ?? new();

            var ocular = oculares.FirstOrDefault(o => o.Id == id);
            if (ocular == null)
                return RedirectToAction("Index");

            return View(ocular);
        }

        [HttpPost]
        public async Task<IActionResult> EditOcular(int id, AltaOcularViewModel vm)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var dto = new
            {
                marca = vm.Marca,
                modelo = vm.Modelo,
                cantDisponible = vm.CantDisponible,
                diametro = vm.Diametro,
                angulo = vm.Angulo
            };

            var response = await client.PutAsJsonAsync($"api/equipo/ocular/{id}", dto);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Ocular actualizado exitosamente";
                return RedirectToAction("Index");
            }

            vm.ErrorMessage = await response.Content.ReadAsStringAsync();
            return View(vm);
        }
    }
}
