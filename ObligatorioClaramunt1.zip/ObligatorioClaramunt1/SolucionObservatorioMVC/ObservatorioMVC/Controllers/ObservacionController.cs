﻿using Microsoft.AspNetCore.Mvc;
using ObservatorioMVC.Models.ObservacionModels;
using ObservatorioMVC.Models.PrestamoModels;

namespace ObservatorioMVC.Controllers
{
    public class ObservacionController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public ObservacionController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        private bool EsSocio()
        {
            return HttpContext.Session.GetString("Rol") == "Socio";
        }

        private int GetUsuarioLogueadoId()
        {
            return int.Parse(HttpContext.Session.GetString("UsuarioId") ?? "0");
        }

        // RF07 - Formulario
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            if (!EsSocio())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            int usuarioId = GetUsuarioLogueadoId();
            var vm = new AltaObservacionViewModel();

            var prestamosResp = await client.GetAsync(
                $"api/prestamo/activos/{usuarioId}");
            var objetosResp = await client.GetAsync(
                "api/observacion/objetoscelestes");

            if (prestamosResp.IsSuccessStatusCode)
                vm.Prestamos = await prestamosResp.Content
                    .ReadFromJsonAsync<List<PrestamoActivoViewModel>>() ?? new();

            if (objetosResp.IsSuccessStatusCode)
                vm.ObjetosCelestes = await objetosResp.Content
                    .ReadFromJsonAsync<List<ObjetoCelesteViewModel>>() ?? new();

            return View(vm);
        }

        // RF07 Validar equipos con Gemini
        [HttpPost]
        public async Task<IActionResult> Evaluar(AltaObservacionViewModel vm)
        {
            if (!EsSocio())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            int usuarioId = GetUsuarioLogueadoId();

            var dto = new
            {
                prestamoId = vm.PrestamoId,
                objetoCelesteId = vm.ObjetoCelesteId
            };

            var response = await client.PostAsJsonAsync(
                "api/observacion/validar", dto);

            if (response.IsSuccessStatusCode)
            {
                var resultado = await response.Content
                    .ReadFromJsonAsync<ValidacionViewModel>();

                vm.IndicadorValidacion = resultado?.Indicador;
                vm.DetalleValidacion = resultado?.Detalle;
                vm.EvaluacionRealizada = true;
            }
            else
            {
                vm.ErrorMessage = await response.Content.ReadAsStringAsync();
            }

            // Recargar opciones
            var prestamosResp = await client.GetAsync(
                $"api/prestamo/activos/{usuarioId}");
            var objetosResp = await client.GetAsync(
                "api/observacion/objetoscelestes");

            if (prestamosResp.IsSuccessStatusCode)
                vm.Prestamos = await prestamosResp.Content
                    .ReadFromJsonAsync<List<PrestamoActivoViewModel>>() ?? new();

            if (objetosResp.IsSuccessStatusCode)
                vm.ObjetosCelestes = await objetosResp.Content
                    .ReadFromJsonAsync<List<ObjetoCelesteViewModel>>() ?? new();

            return View("Create", vm);
        }

        // RF07 Confirmar observacion
        [HttpPost]
        public async Task<IActionResult> Create(AltaObservacionViewModel vm)
        {
            if (!EsSocio())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");

            var dto = new
            {
                prestamoId = vm.PrestamoId,
                objetoCelesteId = vm.ObjetoCelesteId,
                fecha = vm.Fecha
            };

            var response = await client.PostAsJsonAsync("api/observacion", dto);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Observación registrada exitosamente";
                return RedirectToAction("Index", "Home");
            }

            vm.ErrorMessage = await response.Content.ReadAsStringAsync();

            // Recargar opciones para elegir
            int usuarioId = GetUsuarioLogueadoId();
            var prestamosResp = await client.GetAsync(
                $"api/prestamo/activos/{usuarioId}");
            var objetosResp = await client.GetAsync(
                "api/observacion/objetoscelestes");

            if (prestamosResp.IsSuccessStatusCode)
                vm.Prestamos = await prestamosResp.Content
                    .ReadFromJsonAsync<List<PrestamoActivoViewModel>>() ?? new();

            if (objetosResp.IsSuccessStatusCode)
                vm.ObjetosCelestes = await objetosResp.Content
                    .ReadFromJsonAsync<List<ObjetoCelesteViewModel>>() ?? new();

            return View(vm);
        }

        // RF10 Ranking
        [HttpGet]
        public async Task<IActionResult> Ranking()
        {
            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var response = await client.GetAsync("api/observacion/ranking");

            if (response.IsSuccessStatusCode)
            {
                var ranking = await response.Content
                    .ReadFromJsonAsync<List<RankingObjetoCelesteViewModel>>();
                return View(ranking ?? new());
            }

            return View(new List<RankingObjetoCelesteViewModel>());
        }
    }
}
