using Microsoft.AspNetCore.Mvc;
using ObservatorioMVC.Models;
using System.Diagnostics;

namespace ObservatorioMVC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("Rol") == null)
                return RedirectToAction("Login", "Auth");

            string rol = HttpContext.Session.GetString("Rol");
            ViewBag.Rol = rol;
            ViewBag.NombreCompleto = HttpContext.Session.GetString("NombreCompleto");

            return View();
        }
    }
}
