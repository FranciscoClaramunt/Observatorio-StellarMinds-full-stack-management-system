﻿using Microsoft.AspNetCore.Mvc;
using ObservatorioMVC.Models.AuditoriaModels;
using ObservatorioMVC.Models.PrestamoModels;

namespace ObservatorioMVC.Controllers
{
    public class AuditoriaController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public AuditoriaController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        private bool EsAdministrador()
        {
            return HttpContext.Session.GetString("Rol") == "Administrador";
        }

        // RF11 Listar auditorías filtrables
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");
            var vm = new AuditoriaListadoViewModel();

            // Ver todas las auditorías
            var auditoriasResp = await client.GetAsync("api/auditoria");
            if (auditoriasResp.IsSuccessStatusCode)
                vm.Auditorias = await auditoriasResp.Content
                    .ReadFromJsonAsync<List<AuditoriaItemViewModel>>() ?? new();

            // Para ver por coordinador
            var usuariosResp = await client.GetAsync("api/usuario");
            if (usuariosResp.IsSuccessStatusCode)
            {
                var todos = await usuariosResp.Content
                    .ReadFromJsonAsync<List<UsuarioSimpleViewModel>>() ?? new();
                vm.Coordinadores = todos;
            }

            return View(vm);
        }

        [HttpPost]
        public async Task<IActionResult> Index(AuditoriaListadoViewModel vm)
        {
            if (!EsAdministrador())
                return RedirectToAction("Login", "Auth");

            var client = _httpClientFactory.CreateClient("ObservatorioApi");

            string url = vm.CoordinadorId.HasValue
                ? $"api/auditoria?coordinadorId={vm.CoordinadorId}"
                : "api/auditoria";

            var auditoriasResp = await client.GetAsync(url);
            if (auditoriasResp.IsSuccessStatusCode)
                vm.Auditorias = await auditoriasResp.Content
                    .ReadFromJsonAsync<List<AuditoriaItemViewModel>>() ?? new();
            else if ((int)auditoriasResp.StatusCode == 404)
                vm.ErrorMessage = "No se encontraron registros de auditoría";

            var usuariosResp = await client.GetAsync("api/usuario");
            if (usuariosResp.IsSuccessStatusCode)
            {
                var todos = await usuariosResp.Content
                    .ReadFromJsonAsync<List<UsuarioSimpleViewModel>>() ?? new();
                vm.Coordinadores = todos;
            }

            return View(vm);
        }
    }
}
