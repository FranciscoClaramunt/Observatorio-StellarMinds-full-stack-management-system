﻿using Microsoft.AspNetCore.Mvc;
using ObservatorioMVC.Models.UsuarioModels;

namespace ObservatorioMVC.Controllers
{
    public class AuthController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public AuthController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        [HttpGet]
        public IActionResult Login()
        {
            if (HttpContext.Session.GetString("Rol") != null)
                return RedirectToAction("Index", "Home");

            return View(new LoginViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel vm)
        {
            var client = _httpClientFactory.CreateClient("ObservatorioApi");

            var dto = new { nombreUsuario = vm.NombreUsuario, pass = vm.Pass };
            var response = await client.PostAsJsonAsync("api/login", dto);

            if (response.IsSuccessStatusCode)
            {
                var usuario = await response.Content.ReadFromJsonAsync<UsuarioLogueadoViewModel>();

                HttpContext.Session.SetString("UsuarioId", usuario.Id.ToString());
                HttpContext.Session.SetString("NombreUsuario", usuario.NombreUsuario);
                HttpContext.Session.SetString("NombreCompleto", usuario.NombreCompleto);
                HttpContext.Session.SetString("Rol", usuario.Rol);

                return RedirectToAction("Index", "Home");
            }
            else if ((int)response.StatusCode == 401)
            {
                vm.ErrorMessage = "Credenciales inválidas";
                return View(vm);
            }
            else
            {
                vm.ErrorMessage = "Error al iniciar sesión";
                return View(vm);
            }
        }

        [HttpPost]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
